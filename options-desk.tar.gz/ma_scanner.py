"""
MA Scanner — FINAL v3
════════════════════════════════════════════════════════════════
v2 → v3 Düzeltmeleri:
  1. threading.Lock → threading.RLock (deadlock önlemi)
     can_send_ma içinde load+save aynı thread → RLock şart
  2. save_alerts süresi dolmuş kayıtları temizler (dosya şişmez)
  3. Hash eşleşince alerts güncelleme deadlock riski giderildi
  4. Gönderim sırası: kaydet → gönder (crash'e dayanıklı)

DEDUP (üç katmanlı — değişmedi):
  Katman 0: RAM dict (_ram_bellek) — process içi, en hızlı
  Katman 1: /tmp/ma_alerts.json — coin+yön+MA başına 4 saat
  Katman 2: /tmp/ma_sent_hashes.json — son 50 mesaj hash

bot._run_async: bot.py global event loop (çift gönderim yok)
"""

import os
import json
import hashlib
import threading
import requests
import pytz
import time
from datetime import datetime

TR_TZ        = pytz.timezone("Europe/Istanbul")
MA_THREAD_ID = 34221
KANAL_ID     = -1003896040852
MA_PERIODS   = [9, 21, 50, 100, 200]

ALERT_FILE      = "/tmp/ma_alerts.json"
SENT_HASH_FILE  = "/tmp/ma_sent_hashes.json"
MAX_HASH_KAYIT  = 50
BEKLEME_SURESI  = 14400      # 4 saat (saniye)

STABLE_KEYWORDS = ["USDC","BUSD","DAI","TUSD","FDUSD","USDP","USD1","USDE"]

# ─── Kilitler ─────────────────────────────────────────────────
# RLock: aynı thread içinde iç içe lock alınabilir → deadlock yok
_dosya_lock    = threading.RLock()
_gonderim_lock = threading.Lock()
_ram_lock      = threading.Lock()

# ─── RAM Katmanı (Katman 0) ───────────────────────────────────
_ram_bellek: dict = {}


# ════════════════════════════════════════════════════════════════
# DOSYA YARDIMCILARI
# ════════════════════════════════════════════════════════════════

def load_alerts() -> dict:
    with _dosya_lock:
        try:
            with open(ALERT_FILE, "r") as f:
                return json.load(f)
        except Exception:
            return {}


def save_alerts(data: dict):
    """Kaydet + süresi dolmuş kayıtları temizle."""
    with _dosya_lock:
        try:
            simdi = time.time()
            temiz = {k: v for k, v in data.items()
                     if simdi - v < BEKLEME_SURESI * 1.5}
            with open(ALERT_FILE, "w") as f:
                json.dump(temiz, f)
        except Exception as e:
            print(f"[MA] Alert kayıt hatası: {e}")


def load_sent_hashes() -> list:
    with _dosya_lock:
        try:
            with open(SENT_HASH_FILE, "r") as f:
                return json.load(f)
        except Exception:
            return []


def save_sent_hashes(hashes: list):
    with _dosya_lock:
        try:
            with open(SENT_HASH_FILE, "w") as f:
                json.dump(hashes[-MAX_HASH_KAYIT:], f)
        except Exception as e:
            print(f"[MA] Hash kayıt hatası: {e}")


def mesaj_hash(symbol: str, yon: str, temas_ma: int) -> str:
    """
    Hash: symbol + yön + MA periyodu
    Seviye dahil değil — farklı seviyede aynı sinyal tekrar gitmesin.
    """
    return hashlib.md5(f"{symbol}_{yon}_{temas_ma}".encode()).hexdigest()


def is_stable(symbol: str) -> bool:
    return any(k in symbol.replace("USDT", "") for k in STABLE_KEYWORDS)


# ════════════════════════════════════════════════════════════════
# ÜÇ KATMANLI DEDUP
# ════════════════════════════════════════════════════════════════

def can_send_ma(symbol: str, yon: str, temas_ma: int) -> bool:
    """
    Gönderim izni kontrolü — üç katmanlı.

    Katman 0: RAM — aynı process içinde en hızlı kontrol.
    Katman 1: /tmp/ma_alerts.json — 4 saat coin+yön+MA limiti.
    Katman 2: /tmp/ma_sent_hashes.json — son 50 mesaj hash kontrolü.

    True dönerse kayıt zaten yapılmıştır (gönderim öncesi kayıt).
    """
    now     = time.time()
    ram_key = f"{symbol}_{yon}_{temas_ma}"

    # ── Katman 0: RAM ──────────────────────────────────────────
    with _ram_lock:
        son = _ram_bellek.get(ram_key, 0)
        if now - son < BEKLEME_SURESI:
            kalan = int((son + BEKLEME_SURESI - now) / 60)
            print(f"[MA] RAM susturma: {ram_key} ({kalan} dk)")
            return False

    # ── Katman 1: Dosya ────────────────────────────────────────
    alerts = load_alerts()
    last   = alerts.get(ram_key, 0)
    if now - last < BEKLEME_SURESI:
        kalan = int((last + BEKLEME_SURESI - now) / 60)
        print(f"[MA] Dosya susturma: {ram_key} ({kalan} dk)")
        # RAM'e yükle — bir sonraki kontrolde dosyaya gitme
        with _ram_lock:
            _ram_bellek[ram_key] = last
        return False

    # ── Katman 2: Hash ─────────────────────────────────────────
    h      = mesaj_hash(symbol, yon, temas_ma)
    hashes = load_sent_hashes()
    if h in hashes:
        print(f"[MA] Hash eşleşti: {ram_key} — atlandı")
        # Alerts'i güncelle (dosya + RAM) — bir sonraki taramada Katman 1 yakalar
        alerts[ram_key] = now
        save_alerts(alerts)
        with _ram_lock:
            _ram_bellek[ram_key] = now
        return False

    # ── Tümü geçti: önce kaydet, sonra True dön ────────────────
    # Kayıt GÖNDERIMDEN ÖNCE yapılır — crash olsa bile tekrar gönderilmez
    alerts[ram_key] = now
    save_alerts(alerts)

    hashes.append(h)
    save_sent_hashes(hashes)

    with _ram_lock:
        _ram_bellek[ram_key] = now

    print(f"[MA] ✅ Gönderim izni: {ram_key}")
    return True


# ════════════════════════════════════════════════════════════════
# TELEGRAM — bot._run_async (tek global event loop)
# ════════════════════════════════════════════════════════════════

async def _telegram_gonder_async(mesaj: str):
    from telegram import Bot
    bot = Bot(token=os.getenv("BOT_TOKEN"))
    await bot.send_message(
        chat_id=KANAL_ID,
        text=mesaj,
        parse_mode="Markdown",
        message_thread_id=MA_THREAD_ID,
    )
    print("[MA] ✓ Telegram gönderildi")


def telegram_gonder(mesaj: str):
    """
    bot.py global _loop üzerinden gönder.
    _gonderim_lock: aynı anda iki thread'den gönderim imkânsız.
    """
    with _gonderim_lock:
        try:
            import bot as _bot
            _bot._run_async(_telegram_gonder_async(mesaj))
        except Exception as e:
            print(f"[MA] Telegram hatası: {e}")


# ════════════════════════════════════════════════════════════════
# VERİ
# ════════════════════════════════════════════════════════════════

def get_top100_coins() -> list:
    try:
        resp = requests.get(
            "https://fapi.binance.com/fapi/v1/ticker/24hr", timeout=30
        )
        data = sorted(
            resp.json(),
            key=lambda x: float(x["quoteVolume"]),
            reverse=True,
        )
        coins = []
        for s in data:
            sym = s["symbol"]
            if sym.endswith("USDT") and not is_stable(sym):
                coins.append(sym)
            if len(coins) >= 100:
                break
        return coins
    except Exception as e:
        print(f"[MA] Top 100 hatası: {e}")
        return []


def get_daily_closes(symbol: str, limit: int = 250) -> list:
    try:
        resp = requests.get(
            "https://fapi.binance.com/fapi/v1/klines",
            params={"symbol": symbol, "interval": "1d", "limit": limit},
            timeout=15,
        )
        data = resp.json()
        if not isinstance(data, list) or len(data) < 201:
            return []
        return [float(k[4]) for k in data]
    except Exception:
        return []


def get_current_price(symbol: str) -> float | None:
    try:
        resp = requests.get(
            f"https://fapi.binance.com/fapi/v1/ticker/price?symbol={symbol}",
            timeout=10,
        )
        return float(resp.json()["price"])
    except Exception:
        return None


def sma(closes: list, period: int) -> float | None:
    if len(closes) < period:
        return None
    return sum(closes[-period:]) / period


# ════════════════════════════════════════════════════════════════
# SİNYAL KONTROL — Orijinal mantık korundu
# ════════════════════════════════════════════════════════════════

def check_signals(symbol: str, closes: list, current_price: float) -> list:
    signals = []
    mas     = {}
    for p in MA_PERIODS:
        v = sma(closes, p)
        if v:
            mas[p] = v
    if len(mas) < 5:
        return []

    above   = [p for p in MA_PERIODS if current_price >  mas[p]]
    below   = [p for p in MA_PERIODS if current_price <= mas[p]]
    n_above = len(above)
    n_below = len(below)

    def is_touching(price, ma_val):
        return abs(price - ma_val) / ma_val <= 0.0015

    for p in MA_PERIODS:
        if not is_touching(current_price, mas[p]):
            continue
        yon = "YUKARI" if n_above >= n_below else "ASAGI"

        # 1 TOP: 4 MA aynı tarafta, temas eden MA100/200 değil
        if (n_above == 4 or n_below == 4) and p not in [100, 200]:
            signals.append({
                "seviye": 1, "symbol": symbol, "yon": yon,
                "temas_ma": p, "fiyat": current_price,
                "mas": mas, "dinamit": False,
            })
        # 3 TOP (Dinamit): 4 MA aynı tarafta, temas eden karşı taraf MA
        elif (n_above == 4 or n_below == 4):
            if (n_above == 4 and p in below) or (n_below == 4 and p in above):
                signals.append({
                    "seviye": 3, "symbol": symbol, "yon": yon,
                    "temas_ma": p, "fiyat": current_price,
                    "mas": mas, "dinamit": True,
                })

    return signals


# ════════════════════════════════════════════════════════════════
# FORMAT — Orijinal format korundu
# ════════════════════════════════════════════════════════════════

def format_mesaj(sig: dict) -> str:
    mas       = sig["mas"]
    yon       = sig["yon"]
    seviye    = sig["seviye"]
    emoji     = ("🟢" if yon == "YUKARI" else "🔴") * seviye
    yon_emoji = "📈" if yon == "YUKARI" else "📉"
    ma_str    = "\n".join([
        f"  MA{p}: `{round(v, 4)}`" for p, v in sorted(mas.items())
    ])
    mesaj = (
        f"{emoji}\n"
        f"📌 Coin: `{sig['symbol']}`\n"
        f"{yon_emoji} Yon: `{yon}`\n"
        f"🎯 Temas: `MA{sig['temas_ma']}`\n"
        f"💰 Fiyat: `{sig['fiyat']}`\n"
        f"📊 MA Seviyeleri:\n{ma_str}\n"
        f"━━━━━━━━━━━━━━"
    )
    if sig.get("dinamit"):
        mesaj += f"\n\n💥 *{emoji} {sig['symbol']} Dinamite hazırlanıyor...*"
    return mesaj


# ════════════════════════════════════════════════════════════════
# BAŞLANGIÇ: Dosyadan RAM'e yükle
# ════════════════════════════════════════════════════════════════

def _baslangic_yukle():
    """
    Process restart sonrası /tmp/ma_alerts.json'dan
    aktif susturmaları RAM'e yükle.
    """
    alerts = load_alerts()
    simdi  = time.time()
    aktif  = 0
    with _ram_lock:
        for k, v in alerts.items():
            if simdi - v < BEKLEME_SURESI:
                _ram_bellek[k] = v
                aktif += 1
    if aktif:
        print(f"[MA] {aktif} aktif susturma RAM'e yüklendi")
    else:
        print("[MA] Hafıza temiz — tüm sinyaller hazır")


# ════════════════════════════════════════════════════════════════
# ANA TARAMA
# ════════════════════════════════════════════════════════════════

def tarama_yap():
    print(f"[MA] Tarama başlıyor: {datetime.now(TR_TZ).strftime('%H:%M')}")
    coins = get_top100_coins()
    print(f"[MA] {len(coins)} coin taranıyor")
    sayac = 0

    for symbol in coins:
        try:
            closes = get_daily_closes(symbol)
            if not closes:
                continue

            current = get_current_price(symbol)
            if not current:
                continue

            signals = check_signals(symbol, closes, current)
            if not signals:
                continue

            # En yüksek seviyeli sinyali al
            best = max(signals, key=lambda s: s["seviye"])

            # Dedup kontrolü + kayıt (içinde yapılır)
            if not can_send_ma(best["symbol"], best["yon"], best["temas_ma"]):
                continue

            mesaj = format_mesaj(best)
            telegram_gonder(mesaj)
            sayac += 1
            print(f"[MA] ✓ {symbol} — sev={best['seviye']} "
                  f"{best['yon']} — dinamit={best['dinamit']}")
            time.sleep(1)   # Telegram rate limit

        except Exception as e:
            print(f"[MA] {symbol} hatası: {e}")

        time.sleep(0.3)   # Binance rate limit

    print(f"[MA] Tarama tamamlandı — {sayac} sinyal gönderildi")


# ════════════════════════════════════════════════════════════════
# ANA DÖNGÜ
# ════════════════════════════════════════════════════════════════

def ma_scanner_loop():
    """
    bot.py'de thread olarak çalışır:
        threading.Thread(target=ma_scanner_loop, daemon=True).start()

    4 saatte bir tarama — BEKLEME_SURESI ile uyumlu.
    """
    print("[MA] ═══ MA Scanner Başlatıldı ═══")
    print(f"[MA] Susturma: {BEKLEME_SURESI//3600} saat | "
          f"Hash hafızası: {MAX_HASH_KAYIT} mesaj")

    _baslangic_yukle()

    while True:
        try:
            tarama_yap()
        except Exception as e:
            print(f"[MA] Tarama hatası: {e}")

        print(f"[MA] {BEKLEME_SURESI//3600} saat bekleniyor...")
        time.sleep(BEKLEME_SURESI)
