"""
Opsiyon Alarm Modülü v3 — Restart Dayanıklı
─────────────────────────────────────────────
SORUN: Render free tier inaktivite sonrası restart yapıyor.
       Her restart'ta _alarm_bellek sıfırlanıyor → aynı alarm tekrar gidiyor.

ÇÖZÜM: Alarm hafızası /tmp/opsiyon_alarm_bellek.json dosyasına yazılır.
       Restart sonrası dosyadan yüklenir → aynı alarm bir daha gitmez.

Susturma süreleri (dosyada saklanır):
  Hacim Spike : 4 saat (aynı strike için)
  Zero Gamma  : 2 saat
  Call Wall   : 2 saat
  Put Wall    : 2 saat
"""

import os
import json
import time
import asyncio
import threading
import requests
from datetime import datetime

# ─── Ayarlar ─────────────────────────────────────────────────
OPSIYON_CHAT_ID   = -1003896040852
OPSIYON_THREAD_ID = 2

BELLEK_DOSYA = "/tmp/opsiyon_alarm_bellek.json"

SESSIZ = {
    "spike":      4 * 3600,   # 4 saat — aynı strike
    "zero_gamma": 2 * 3600,   # 2 saat
    "call_wall":  2 * 3600,   # 2 saat
    "put_wall":   2 * 3600,   # 2 saat
}

# ─── Dosya Tabanlı Alarm Hafızası ────────────────────────────
_dosya_lock = threading.Lock()


def _bellek_oku() -> dict:
    """Alarm hafızasını dosyadan oku."""
    with _dosya_lock:
        try:
            with open(BELLEK_DOSYA, "r") as f:
                return json.load(f)
        except Exception:
            return {}


def _bellek_yaz(data: dict):
    """Alarm hafızasını dosyaya yaz."""
    with _dosya_lock:
        try:
            with open(BELLEK_DOSYA, "w") as f:
                json.dump(data, f)
        except Exception as e:
            print(f"[OpsiyonAlarm] Bellek yazma hatası: {e}")


def _gonderildi_mi(anahtar: str) -> bool:
    """
    Bu alarm daha önce gönderildi mi?
    Dosyadan okur — restart'a dayanıklı.
    """
    tur  = anahtar.split("_")[0]
    sure = SESSIZ.get(tur, 2 * 3600)
    data = _bellek_oku()
    son  = data.get(anahtar, 0)
    sonuc = (time.time() - son) < sure
    if sonuc:
        kalan = int(sure - (time.time() - son)) // 60
        print(f"[OpsiyonAlarm] Susturma aktif: {anahtar} ({kalan} dk kaldı)")
    return sonuc


def _kaydet(anahtar: str):
    """Alarm gönderim zamanını dosyaya yaz."""
    data = _bellek_oku()
    data[anahtar] = time.time()

    # Süresi dolmuş kayıtları temizle (dosya şişmesin)
    simdi = time.time()
    data = {
        k: v for k, v in data.items()
        if (simdi - v) < max(SESSIZ.values()) * 1.5
    }

    _bellek_yaz(data)
    print(f"[OpsiyonAlarm] Kaydedildi: {anahtar}")


# ─── Gönderim Kilidi ─────────────────────────────────────────
_gonderim_lock = threading.Lock()


def _gonder(mesaj: str):
    """Thread-safe tekil gönderim."""
    with _gonderim_lock:
        try:
            loop = asyncio.new_event_loop()
            loop.run_until_complete(_tg_gonder(mesaj))
            loop.close()
        except Exception as e:
            print(f"[OpsiyonAlarm] Gönderim hatası: {e}")


async def _tg_gonder(mesaj: str):
    from telegram import Bot
    token = os.getenv("BOT_TOKEN")
    if not token:
        print("[OpsiyonAlarm] BOT_TOKEN bulunamadı")
        return
    try:
        bot = Bot(token=token)
        await bot.send_message(
            chat_id=OPSIYON_CHAT_ID,
            text=mesaj,
            parse_mode="HTML",
            message_thread_id=OPSIYON_THREAD_ID,
            disable_web_page_preview=True,
        )
        print(f"[OpsiyonAlarm] ✓ Telegram'a gönderildi")
    except Exception as e:
        print(f"[OpsiyonAlarm] Telegram hatası: {e}")


# ─── Deribit API ─────────────────────────────────────────────
DERIBIT = "https://www.deribit.com/api/v2/public"


def _deribit(method: str, params: dict = None):
    try:
        r = requests.get(
            f"{DERIBIT}/{method}",
            params=params or {},
            timeout=12,
        )
        r.raise_for_status()
        return r.json().get("result")
    except Exception as e:
        print(f"[OpsiyonAlarm] Deribit/{method} hatası: {e}")
        return None


def _spot_al() -> float:
    d = _deribit("get_index_price", {"index_name": "btc_usd"})
    return float(d.get("index_price", 0)) if d else 0.0


# ─── 0-7 Günlük Opsiyonlar ───────────────────────────────────
def _kisa_vadeli_opsiyonlar() -> list:
    enstrumanlar = _deribit("get_instruments", {
        "currency": "BTC", "kind": "option", "expired": "false"
    })
    if not enstrumanlar:
        return []

    now_ms      = int(time.time() * 1000)
    yedi_gun_ms = 7 * 24 * 3600 * 1000
    # Spike anahtarı için tarih: günlük — aynı gün aynı strike tekrar gitmesin
    bugun_str   = datetime.utcnow().strftime("%Y%m%d")

    kisa = [
        i for i in enstrumanlar
        if 0 < (i.get("expiration_timestamp", 0) - now_ms) <= yedi_gun_ms
    ]

    sonuclar = []
    for inst in kisa[:30]:
        t = _deribit("ticker", {"instrument_name": inst["instrument_name"]})
        if not (t and t.get("open_interest", 0) > 0):
            time.sleep(0.05)
            continue
        sonuclar.append({
            # Anahtar: tarih+strike+tip — restart'ta bile aynı kalır
            "anahtar_id": f"{bugun_str}_{int(inst['strike'])}_{inst['option_type']}",
            "inst":       inst["instrument_name"],
            "strike":     inst["strike"],
            "type":       inst["option_type"],
            "oi":         float(t.get("open_interest", 0)),
            "iv":         float(t.get("mark_iv", 0)),
            "vade_gun":   round((inst["expiration_timestamp"] - now_ms) / 86400000, 1),
        })
        time.sleep(0.05)

    return sonuclar


# ─── Key Seviyeler ───────────────────────────────────────────
def _key_seviyeler(spot: float) -> dict | None:
    enstrumanlar = _deribit("get_instruments", {
        "currency": "BTC", "kind": "option", "expired": "false"
    })
    if not enstrumanlar or not spot:
        return None

    strike_map: dict = {}
    for inst in enstrumanlar[:60]:
        t = _deribit("ticker", {"instrument_name": inst["instrument_name"]})
        if not t:
            time.sleep(0.04)
            continue
        k           = inst["strike"]
        oi          = float(t.get("open_interest", 0))
        tip         = inst["option_type"]
        delta_proxy = max(0.01, 1.0 - abs(k - spot) / spot)
        gex         = oi * delta_proxy * spot * 0.01
        if k not in strike_map:
            strike_map[k] = {"call_gex": 0.0, "put_gex": 0.0}
        if tip == "call":
            strike_map[k]["call_gex"] += gex
        else:
            strike_map[k]["put_gex"] -= gex
        time.sleep(0.04)

    if not strike_map:
        return None

    return {
        "call_wall":  max(strike_map, key=lambda k: strike_map[k]["call_gex"]),
        "put_wall":   min(strike_map, key=lambda k: strike_map[k]["put_gex"]),
        "zero_gamma": min(strike_map, key=lambda k: abs(
            strike_map[k]["call_gex"] + strike_map[k]["put_gex"]
        )),
    }


# ─── Format ──────────────────────────────────────────────────
def _fmt(n) -> str:
    return f"{n:,.0f}" if n else "—"

def _pct(n, d=2) -> str:
    return f"{n:+.{d}f}%" if n is not None else "—"


# ─── Alarm İşleyicileri ──────────────────────────────────────

def _hacim_spike_isle(opsiyonlar: list, spot: float, zaman: str):
    if len(opsiyonlar) < 3:
        return
    oi_listesi = [o["oi"] for o in opsiyonlar if o["oi"] > 0]
    if not oi_listesi:
        return
    ortalama = sum(oi_listesi) / len(oi_listesi)
    esik     = ortalama * 2.5
    spikeler = sorted(
        [o for o in opsiyonlar if o["oi"] >= esik],
        key=lambda o: o["oi"], reverse=True
    )[:3]

    for sp in spikeler:
        anahtar = f"spike_{sp['anahtar_id']}"
        if _gonderildi_mi(anahtar):
            continue   # dosyada kayıtlı, atla

        tip  = "📗 CALL" if sp["type"] == "call" else "📕 PUT"
        oran = sp["oi"] / ortalama if ortalama else 0
        mesaj = (
            f"⚡ <b>HACİM SPİKE — 0-7g BTC Opsiyonu</b>\n"
            f"━━━━━━━━━━━━━━━━━━━━━\n"
            f"{tip} | Strike: <b>${_fmt(sp['strike'])}</b>\n"
            f"Vade: <b>{sp['vade_gun']} gün</b>\n"
            f"Açık Pozisyon: <b>{_fmt(sp['oi'])} BTC</b>\n"
            f"Ortalama: {_fmt(ortalama)} BTC — Eşik: {_fmt(esik)} BTC\n"
            f"Oran: <b>{oran:.1f}x</b> ortalama\n"
            f"IV: {sp['iv']:.1f}%\n"
            f"Spot: <b>${_fmt(spot)}</b>\n\n"
            f"📊 <b>Hull Analizi (Bölüm 18):</b>\n"
            f"Kısa vadeli opsiyonda olağandışı OI birikimi. "
            f"Vadeye yakın yüksek OI = güçlü pin riski. "
            f"Dealer'lar bu strike'ta delta hedge baskısı oluşturur.\n\n"
            f"<i>{zaman}</i>"
        )
        # ÖNEMLİ: Önce dosyaya kaydet, sonra gönder
        # → Restart olsa bile tekrar gitmez
        _kaydet(anahtar)
        _gonder(mesaj)


def _zero_gamma_isle(spot: float, zg: float, zaman: str):
    uzaklik = abs((spot - zg) / spot * 100)
    if uzaklik > 0.5:
        return
    anahtar = "zero_gamma"
    if _gonderildi_mi(anahtar):
        return
    yon = "ÜSTÜNDE ↑" if spot > zg else "ALTINDA ↓"
    mesaj = (
        f"🔶 <b>ZERO GAMMA TEMASINDA — BTC</b>\n"
        f"━━━━━━━━━━━━━━━━━━━━━\n"
        f"Spot: <b>${_fmt(spot)}</b>\n"
        f"Zero Gamma: <b>${_fmt(zg)}</b>\n"
        f"Uzaklık: <b>{uzaklik:.2f}%</b> — Spot ZG {yon}\n\n"
        f"📊 <b>Hull Analizi (Bölüm 19.6):</b>\n"
        f"Zero Gamma dealer gamma rejiminin kırılma noktasıdır.\n"
        f"• Spot ZG üstü → Dealer long gamma → Mean-reversion baskısı\n"
        f"• Spot ZG altı → Dealer short gamma → Momentum / Vol artışı\n\n"
        f"⚡ Bu seviye kırılırsa volatilite amplifikasyonu beklenir.\n\n"
        f"<i>{zaman}</i>"
    )
    _kaydet(anahtar)
    _gonder(mesaj)


def _call_wall_isle(spot: float, cw: float, zaman: str):
    uzaklik = (cw - spot) / spot * 100
    if not (0 <= uzaklik <= 0.3):
        return
    anahtar = "call_wall"
    if _gonderildi_mi(anahtar):
        return
    mesaj = (
        f"📗 <b>CALL WALL TEMASINDA — BTC</b>\n"
        f"━━━━━━━━━━━━━━━━━━━━━\n"
        f"Spot: <b>${_fmt(spot)}</b>\n"
        f"Call Wall: <b>${_fmt(cw)}</b>\n"
        f"Uzaklık: <b>{_pct(uzaklik)}</b>\n\n"
        f"📊 <b>Hull Analizi (Bölüm 19.5):</b>\n"
        f"Call Wall = maksimum pozitif gamma yoğunlaşması.\n"
        f"• Dealer burada delta satışı başlatır\n"
        f"• Spot'un CW'u kırması zor — güçlü direnç\n"
        f"• Kırılım → short squeeze + gamma squeeze riski\n\n"
        f"<i>{zaman}</i>"
    )
    _kaydet(anahtar)
    _gonder(mesaj)


def _put_wall_isle(spot: float, pw: float, zaman: str):
    uzaklik = (spot - pw) / spot * 100
    if not (0 <= uzaklik <= 0.3):
        return
    anahtar = "put_wall"
    if _gonderildi_mi(anahtar):
        return
    mesaj = (
        f"📕 <b>PUT WALL TEMASINDA — BTC</b>\n"
        f"━━━━━━━━━━━━━━━━━━━━━\n"
        f"Spot: <b>${_fmt(spot)}</b>\n"
        f"Put Wall: <b>${_fmt(pw)}</b>\n"
        f"Uzaklık: <b>{_pct(uzaklik)}</b>\n\n"
        f"📊 <b>Hull Analizi (Bölüm 19.5):</b>\n"
        f"Put Wall = maksimum negatif gamma yoğunlaşması.\n"
        f"• Dealer burada delta alımı başlatır (destek)\n"
        f"• Kırılım → gamma negatife döner, vol genişler\n"
        f"• Hızlı aşağı hareket riski artar\n\n"
        f"<i>{zaman}</i>"
    )
    _kaydet(anahtar)
    _gonder(mesaj)


# ─── Ana Döngü ───────────────────────────────────────────────
def opsiyon_alarm_loop():
    """
    Her 15 dakikada bir çalışır.
    Alarm hafızası /tmp/opsiyon_alarm_bellek.json dosyasında tutulur.
    Render restart sonrası aynı alarm tekrar gitmez.
    """
    print("[OpsiyonAlarm] Başlatıldı — 15 dakika aralık, seviyeler saatlik güncelleme")
    print(f"[OpsiyonAlarm] Alarm hafızası: {BELLEK_DOSYA}")

    # Mevcut hafızayı göster
    mevcut = _bellek_oku()
    if mevcut:
        print(f"[OpsiyonAlarm] Mevcut hafıza yüklendi: {list(mevcut.keys())}")
    else:
        print("[OpsiyonAlarm] Hafıza boş — ilk çalıştırma")

    ARALIK        = 15 * 60
    SEVIYE_ARALIK = 60 * 60
    son_seviye_ts = 0.0
    seviyeler     = None

    while True:
        try:
            now   = time.time()
            zaman = datetime.utcnow().strftime("%d.%m.%Y %H:%M UTC")

            # 1. Spot — tek seferlik
            spot = _spot_al()
            if not spot:
                print("[OpsiyonAlarm] Spot alınamadı, bekleniyor...")
                time.sleep(ARALIK)
                continue

            print(f"[OpsiyonAlarm] Kontrol — Spot: ${_fmt(spot)} — {zaman}")

            # 2. Seviyeler — saatlik
            if (now - son_seviye_ts) >= SEVIYE_ARALIK:
                print("[OpsiyonAlarm] Seviyeler hesaplanıyor...")
                seviyeler     = _key_seviyeler(spot)
                son_seviye_ts = now
                if seviyeler:
                    print(
                        f"[OpsiyonAlarm] CW=${_fmt(seviyeler['call_wall'])} "
                        f"PW=${_fmt(seviyeler['put_wall'])} "
                        f"ZG=${_fmt(seviyeler['zero_gamma'])}"
                    )

            # 3. 0-7g opsiyonlar
            opsiyonlar = _kisa_vadeli_opsiyonlar()
            print(f"[OpsiyonAlarm] {len(opsiyonlar)} kısa vadeli opsiyon")

            # 4. Alarmlar
            _hacim_spike_isle(opsiyonlar, spot, zaman)
            if seviyeler:
                _zero_gamma_isle(spot, seviyeler["zero_gamma"], zaman)
                _call_wall_isle(spot, seviyeler["call_wall"],   zaman)
                _put_wall_isle(spot,  seviyeler["put_wall"],    zaman)

        except Exception as e:
            print(f"[OpsiyonAlarm] Genel hata: {e}")

        time.sleep(ARALIK)
