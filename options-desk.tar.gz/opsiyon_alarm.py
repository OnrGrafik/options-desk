"""
Opsiyon Alarm Modülü — FINAL v3
════════════════════════════════════════════════════════════════
DEĞİŞİKLİKLER (v2 → v3):
  • CW/PW/ZG temas bildirimi kaldırıldı
  • 8 saatte bir CW/PW/ZG güncelleme mesajı eklendi
  • Deadlock riski giderildi: _dosya_lock → threading.RLock()
  • _gonderildi_mi anahtar türü güvenli çıkarma
  • Spike anahtarı tarih yerine 4 saatlik slot bazlı
    (gece yarısı UTC geçişinde susturma sıfırlanmaz)
  • max_s sabit 12 saat (SESSIZ dict bağımsız)
  • bot._run_async ile tek global event loop

DEDUP (spike için):
  Katman 1: RAM dict — process içi
  Katman 2: /tmp/alarm_durum.json — deploy sonrası
  Sıra: _kaydet() → _gonder() (önce kaydet → sonra gönder)

GÜNCELLEME (CW/PW/ZG):
  Her 8 saatte bir bilgi mesajı — dedup uygulanmaz
  Saatlik seviye hesabı devam eder (güncelleme için)
"""

import os
import json
import math
import time
import threading
import requests
from datetime import datetime

# ─── Kanal ────────────────────────────────────────────────────
OPSIYON_CHAT_ID   = -1003896040852
OPSIYON_THREAD_ID = 2

# ─── Eşikler ──────────────────────────────────────────────────
SPIKE_MIN_OI      = 1000        # BTC — altı ignore
SPIKE_SESSIZ      = 4 * 3600    # Aynı spike 4 saat tekrar etmez
GUNCELLEME_ARALIK = 8 * 3600    # CW/PW/ZG güncelleme mesajı aralığı

# ─── Durum Dosyası ────────────────────────────────────────────
DURUM_DOSYA = "/tmp/alarm_durum.json"

# ─── Kilitler ─────────────────────────────────────────────────
# RLock: aynı thread içinde iç içe lock alınabilir (deadlock önler)
_dosya_lock    = threading.RLock()
_ram_lock      = threading.Lock()
_gonderim_lock = threading.Lock()

# ─── RAM Katmanı ──────────────────────────────────────────────
_ram_bellek: dict = {}   # {anahtar: unix_ts}


# ════════════════════════════════════════════════════════════════
# DEDUP — Sadece spike için (CW/PW/ZG'de kullanılmaz)
# ════════════════════════════════════════════════════════════════

def _dosya_oku() -> dict:
    with _dosya_lock:
        try:
            with open(DURUM_DOSYA, "r") as f:
                return json.load(f)
        except Exception:
            return {}


def _dosya_yaz(data: dict):
    # Sabit 12 saat — SESSIZ dict bağımsız
    MAX_SURE = 12 * 3600
    with _dosya_lock:
        try:
            simdi = time.time()
            temiz = {k: v for k, v in data.items() if simdi - v < MAX_SURE}
            with open(DURUM_DOSYA, "w") as f:
                json.dump(temiz, f)
        except Exception as e:
            print(f"[OpsiyonAlarm] Dosya yazma: {e}")


def _spike_gonderildi_mi(anahtar: str) -> bool:
    """
    Spike dedup kontrolü.
    Anahtar: "spike_SLOT_STRIKE_TIP"
    SLOT = unix_ts // SPIKE_SESSIZ (4 saatlik zaman dilimi)
    → Gece yarısı UTC'de sıfırlanmaz, tam 4 saat korunur.
    """
    simdi = time.time()

    # Katman 1: RAM
    with _ram_lock:
        son = _ram_bellek.get(anahtar, 0)
        if simdi - son < SPIKE_SESSIZ:
            print(f"[OpsiyonAlarm] RAM susturma: {anahtar} "
                  f"({int((son + SPIKE_SESSIZ - simdi) / 60)} dk)")
            return True

    # Katman 2: Dosya
    data = _dosya_oku()
    son  = data.get(anahtar, 0)
    if simdi - son < SPIKE_SESSIZ:
        print(f"[OpsiyonAlarm] Dosya susturma: {anahtar} "
              f"({int((son + SPIKE_SESSIZ - simdi) / 60)} dk)")
        with _ram_lock:
            _ram_bellek[anahtar] = son   # RAM'e yükle
        return True

    return False


def _spike_kaydet(anahtar: str):
    """Spike kaydını RAM + dosyaya yaz."""
    simdi = time.time()
    with _ram_lock:
        _ram_bellek[anahtar] = simdi
    data = _dosya_oku()
    data[anahtar] = simdi
    _dosya_yaz(data)
    print(f"[OpsiyonAlarm] Spike kaydedildi: {anahtar}")


def _spike_kaydet_ve_gonder(anahtar: str, mesaj: str):
    """
    Önce kaydet → sonra gönder.
    Kayıt başarısız olursa gönderilmez.
    Crash olsa bile tekrar gönderilmez.
    """
    _spike_kaydet(anahtar)
    _gonder(mesaj)


# ════════════════════════════════════════════════════════════════
# TELEGRAM — bot._run_async (tek global event loop)
# ════════════════════════════════════════════════════════════════

async def _tg_gonder_async(mesaj: str):
    from telegram import Bot
    bot = Bot(token=os.getenv("BOT_TOKEN"))
    await bot.send_message(
        chat_id=OPSIYON_CHAT_ID,
        text=mesaj,
        parse_mode="HTML",
        message_thread_id=OPSIYON_THREAD_ID,
        disable_web_page_preview=True,
    )
    print("[OpsiyonAlarm] ✓ Telegram gönderildi")


def _gonder(mesaj: str):
    """bot.py global _loop üzerinden gönder — event loop çakışması yok."""
    with _gonderim_lock:
        try:
            import bot as _bot
            _bot._run_async(_tg_gonder_async(mesaj))
        except Exception as e:
            print(f"[OpsiyonAlarm] Gönderim hatası: {e}")


# ════════════════════════════════════════════════════════════════
# MATEMATİK — Hull 11e
# ════════════════════════════════════════════════════════════════

def _norm_pdf(x: float) -> float:
    return math.exp(-0.5 * x * x) / math.sqrt(2 * math.pi)


def _bs_gamma(S: float, K: float, T: float, sigma: float) -> float:
    """Hull Bölüm 19.6: Γ = N'(d1) / (S·σ·√T), r=q=0"""
    if T <= 0 or sigma <= 0 or S <= 0 or K <= 0:
        return 0.0
    sqT = math.sqrt(T)
    d1  = (math.log(S / K) + 0.5 * sigma * sigma * T) / (sigma * sqT)
    return _norm_pdf(d1) / (S * sigma * sqT)


# ════════════════════════════════════════════════════════════════
# DERİBİT API
# ════════════════════════════════════════════════════════════════

DERIBIT = "https://www.deribit.com/api/v2/public"


def _deribit(method: str, params: dict = None):
    try:
        r = requests.get(
            f"{DERIBIT}/{method}",
            params=params or {},
            timeout=12,
        )
        r.raise_for_status()
        return r.json().get("result")
    except Exception as e:
        print(f"[OpsiyonAlarm] Deribit/{method}: {e}")
        return None


def _spot_al() -> float:
    d = _deribit("get_index_price", {"index_name": "btc_usd"})
    return float(d.get("index_price", 0)) if d else 0.0


def _kisa_vadeli_opsiyonlar() -> list:
    """0-7 günlük, OI > SPIKE_MIN_OI olan BTC opsiyonları."""
    enstrumanlar = _deribit("get_instruments", {
        "currency": "BTC", "kind": "option", "expired": "false"
    })
    if not enstrumanlar:
        return []
    now_ms   = int(time.time() * 1000)
    yedi_gun = 7 * 24 * 3600 * 1000
    kisa     = [i for i in enstrumanlar
                if 0 < (i.get("expiration_timestamp", 0) - now_ms) <= yedi_gun]
    sonuclar = []
    for inst in kisa[:30]:
        t = _deribit("ticker", {"instrument_name": inst["instrument_name"]})
        if not t:
            time.sleep(0.05)
            continue
        oi = float(t.get("open_interest", 0))
        if oi < SPIKE_MIN_OI:
            time.sleep(0.05)
            continue
        sonuclar.append({
            "strike":   inst["strike"],
            "tip":      inst["option_type"],
            "oi":       oi,
            "iv":       float(t.get("mark_iv", 0)),
            "vade_gun": round((inst["expiration_timestamp"] - now_ms) / 86400000, 1),
        })
        time.sleep(0.05)
    return sonuclar


def _key_seviyeler(spot: float) -> dict | None:
    """GEX bazlı Call Wall / Put Wall / Zero Gamma hesapla."""
    enstrumanlar = _deribit("get_instruments", {
        "currency": "BTC", "kind": "option", "expired": "false"
    })
    if not enstrumanlar or not spot:
        return None
    now_ms     = int(time.time() * 1000)
    strike_map = {}
    for inst in enstrumanlar[:60]:
        t = _deribit("ticker", {"instrument_name": inst["instrument_name"]})
        if not t:
            time.sleep(0.04)
            continue
        k   = inst["strike"]
        oi  = float(t.get("open_interest", 0))
        iv  = float(t.get("mark_iv", 50)) / 100.0
        tip = inst["option_type"]
        T   = max((inst["expiration_timestamp"] - now_ms) /
                  (365.25 * 24 * 3600 * 1000), 0.0001)
        gex = _bs_gamma(spot, k, T, iv) * oi * spot * spot * 0.01
        if k not in strike_map:
            strike_map[k] = {"call_gex": 0.0, "put_gex": 0.0}
        if tip == "call":
            strike_map[k]["call_gex"] += gex
        else:
            strike_map[k]["put_gex"]  -= gex
        time.sleep(0.04)
    if not strike_map:
        return None
    return {
        "call_wall":  float(max(strike_map,
                           key=lambda k: strike_map[k]["call_gex"])),
        "put_wall":   float(min(strike_map,
                           key=lambda k: strike_map[k]["put_gex"])),
        "zero_gamma": float(min(strike_map,
                           key=lambda k: abs(
                               strike_map[k]["call_gex"] +
                               strike_map[k]["put_gex"]))),
    }


# ════════════════════════════════════════════════════════════════
# FORMAT
# ════════════════════════════════════════════════════════════════

def _fmt(n) -> str:
    return f"{n:,.0f}" if n else "—"

def _pct(n: float, d: int = 2) -> str:
    return f"{n:+.{d}f}%"


# ════════════════════════════════════════════════════════════════
# HAC İM SPİKE ALARMI
# ════════════════════════════════════════════════════════════════

def _hacim_spike_isle(opsiyonlar: list, spot: float, zaman: str):
    """
    OI > 1000 BTC olan 0-7g opsiyonları bildir.
    Anahtar: slot bazlı (4 saatlik UTC dilimi) + strike + tip
    → Gece yarısı geçişinde susturma sıfırlanmaz.
    """
    if not opsiyonlar:
        return

    # 4 saatlik slot: aynı 4 saat diliminde aynı strike tekrar gitmez
    slot = int(time.time()) // SPIKE_SESSIZ

    for sp in sorted(opsiyonlar, key=lambda o: o["oi"], reverse=True)[:3]:
        anahtar = f"spike_{slot}_{int(sp['strike'])}_{sp['tip']}"

        if _spike_gonderildi_mi(anahtar):
            continue

        tip  = "📗 CALL" if sp["tip"] == "call" else "📕 PUT"
        uzak = (sp["strike"] - spot) / spot * 100
        mesaj = (
            f"⚡ <b>HACİM SPİKE — 0-7g BTC Opsiyonu</b>\n"
            f"━━━━━━━━━━━━━━━━━━━━━\n"
            f"{tip} | Strike: <b>${_fmt(sp['strike'])}</b>"
            f" ({_pct(uzak)} spot'tan)\n"
            f"Vade: <b>{sp['vade_gun']} gün</b>\n"
            f"Açık Pozisyon: <b>{_fmt(sp['oi'])} BTC</b>\n"
            f"IV: {sp['iv']:.1f}% | Spot: <b>${_fmt(spot)}</b>\n\n"
            f"📊 <b>Hull Analizi (Bölüm 18):</b>\n"
            f"1000 BTC üzeri kısa vadeli OI birikimi. "
            f"Vadeye yakın yüksek OI = güçlü pin riski. "
            f"Dealer'lar bu strike'ta delta hedge baskısı oluşturur.\n\n"
            f"<i>{zaman}</i>"
        )
        _spike_kaydet_ve_gonder(anahtar, mesaj)
        time.sleep(1)


# ════════════════════════════════════════════════════════════════
# CW/PW/ZG GÜNCELLEME MESAJI — 8 saatte bir, dedup yok
# ════════════════════════════════════════════════════════════════

def _seviye_guncelleme_gonder(spot: float, seviyeler: dict, zaman: str):
    """
    CW / PW / Zero Gamma bilgi mesajı.
    Temas alarmı değil, sadece seviye güncelleme.
    Dedup uygulanmaz — her 8 saatte bir kesinlikle gönderilir.
    """
    cw = seviyeler["call_wall"]
    pw = seviyeler["put_wall"]
    zg = seviyeler["zero_gamma"]

    # Uzaklık hesapları
    cw_uzak  = (cw  - spot) / spot * 100
    pw_uzak  = (spot - pw)  / spot * 100
    zg_uzak  = (spot - zg)  / spot * 100

    # Spot ZG'ye göre konum
    zg_konum = "ZG ÜSTÜNDE ↑ (Long Gamma)" if spot > zg else "ZG ALTINDA ↓ (Short Gamma)"

    mesaj = (
        f"📊 <b>OPSİYON BÖLGE GÜNCELLEMESİ — BTC</b>\n"
        f"━━━━━━━━━━━━━━━━━━━━━\n"
        f"Spot: <b>${_fmt(spot)}</b>\n\n"
        f"📗 <b>Call Wall:</b> ${_fmt(cw)}"
        f" ({_pct(cw_uzak)} spot'tan yukarıda)\n"
        f"📕 <b>Put Wall:</b>  ${_fmt(pw)}"
        f" ({_pct(-pw_uzak)} spot'tan aşağıda)\n"
        f"🔶 <b>Zero Gamma:</b> ${_fmt(zg)}"
        f" ({_pct(zg_uzak)} fark) — {zg_konum}\n\n"
        f"<b>Bölge Yorumu:</b>\n"
        f"• Spot CW ({_fmt(cw)}) altında → Dealer direnç satışı beklenir\n"
        f"• Spot PW ({_fmt(pw)}) üstünde → Dealer destek alımı beklenir\n"
        f"• {zg_konum.split('(')[0].strip()} → "
        f"{'Ortalamaya dönüş eğilimi güçlü' if spot > zg else 'Yönsel hareket ve volatilite artışı olası'}\n\n"
        f"<i>8 saatlik güncelleme · {zaman}</i>"
    )
    _gonder(mesaj)
    print(f"[OpsiyonAlarm] 8 saatlik seviye güncellemesi gönderildi")


# ════════════════════════════════════════════════════════════════
# BAŞLANGIÇ
# ════════════════════════════════════════════════════════════════

def _baslangic_yukle():
    """Dosyadaki aktif spike susturmalarını RAM'e yükle."""
    data  = _dosya_oku()
    simdi = time.time()
    aktif = 0
    with _ram_lock:
        for k, v in data.items():
            if simdi - v < SPIKE_SESSIZ:
                _ram_bellek[k] = v
                aktif += 1
    if aktif:
        print(f"[OpsiyonAlarm] {aktif} aktif spike susturması RAM'e yüklendi")
    else:
        print("[OpsiyonAlarm] Hafıza temiz — tüm spike alarmları hazır")


# ════════════════════════════════════════════════════════════════
# ANA DÖNGÜ
# ════════════════════════════════════════════════════════════════

def opsiyon_alarm_loop():
    """
    Zamanlama:
      • Spike kontrolü : her 15 dakika (OI > 1000 BTC)
      • Seviye hesabı  : her 60 dakika (CW/PW/ZG)
      • Güncelleme msg : her 8 saat (CW/PW/ZG bilgi mesajı)

    bot.py'de thread olarak başlatılır:
        threading.Thread(target=opsiyon_alarm_loop, daemon=True).start()
    """
    print("[OpsiyonAlarm] ═══ Başlatıldı ═══")
    print(f"[OpsiyonAlarm] Spike eşiği: {SPIKE_MIN_OI} BTC | "
          f"Spike susturma: {SPIKE_SESSIZ//3600} saat | "
          f"Güncelleme: {GUNCELLEME_ARALIK//3600} saat")

    _baslangic_yukle()

    SPIKE_ARALIK  = 15 * 60    # 15 dakika
    SEVIYE_ARALIK = 60 * 60    # 60 dakika

    son_seviye_ts    = 0.0
    son_guncelleme   = 0.0
    seviyeler        = None
    dongu            = 0

    while True:
        try:
            dongu += 1
            simdi  = time.time()
            zaman  = datetime.utcnow().strftime("%d.%m.%Y %H:%M UTC")

            # ── Spot ──────────────────────────────────────────────
            spot = _spot_al()
            if not spot:
                print("[OpsiyonAlarm] Spot alınamadı, bekleniyor...")
                time.sleep(SPIKE_ARALIK)
                continue

            print(f"\n[OpsiyonAlarm] ── Döngü #{dongu} ──")
            print(f"[OpsiyonAlarm] Spot: ${_fmt(spot)} | {zaman}")

            # ── Seviye Hesabı — saatlik ───────────────────────────
            if (simdi - son_seviye_ts) >= SEVIYE_ARALIK:
                print("[OpsiyonAlarm] Seviyeler hesaplanıyor...")
                seviyeler     = _key_seviyeler(spot)
                son_seviye_ts = time.time()
                if seviyeler:
                    print(
                        f"[OpsiyonAlarm] "
                        f"CW=${_fmt(seviyeler['call_wall'])} | "
                        f"PW=${_fmt(seviyeler['put_wall'])} | "
                        f"ZG=${_fmt(seviyeler['zero_gamma'])}"
                    )

            # ── 8 Saatlik Güncelleme Mesajı ───────────────────────
            if seviyeler and (simdi - son_guncelleme) >= GUNCELLEME_ARALIK:
                _seviye_guncelleme_gonder(spot, seviyeler, zaman)
                son_guncelleme = time.time()

            # ── Hacim Spike Kontrolü ──────────────────────────────
            opsiyonlar = _kisa_vadeli_opsiyonlar()
            print(f"[OpsiyonAlarm] OI>{SPIKE_MIN_OI} BTC: {len(opsiyonlar)} kontrat")
            _hacim_spike_isle(opsiyonlar, spot, zaman)

        except Exception as e:
            print(f"[OpsiyonAlarm] Hata: {e}")

        time.sleep(SPIKE_ARALIK)
