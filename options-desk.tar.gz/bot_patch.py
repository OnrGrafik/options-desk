"""
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
MEVCUT bot.py'ye EKLENECEK SATIRLAR
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

1. DOSYA BAŞINA (diğer import'ların yanına) ekle:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
"""

# ── EKLE: Diğer try/import bloklarının yanına ──────────────
try:
    from opsiyon_alarm import opsiyon_alarm_loop
    print("Opsiyon alarm import OK")
except Exception as e:
    print(f"HATA - Opsiyon alarm: {e}")

try:
    from makro_alarm import makro_alarm_loop
    print("Makro alarm import OK")
except Exception as e:
    print(f"HATA - Makro alarm: {e}")


"""
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
2. if __name__ == "__main__": BLOĞUNA ekle
   (örn: trade_tracker başlatıldıktan sonra)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
"""

# ── EKLE: Alarm döngülerini başlat ─────────────────────────
try:
    import threading
    threading.Thread(target=opsiyon_alarm_loop, daemon=True).start()
    print("Opsiyon alarm başlatıldı")
except Exception as e:
    print(f"Opsiyon alarm başlatma hatası: {e}")

try:
    threading.Thread(target=makro_alarm_loop, daemon=True).start()
    print("Makro alarm başlatıldı")
except Exception as e:
    print(f"Makro alarm başlatma hatası: {e}")


"""
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
3. ENVIRONMENT DEĞİŞKENİ EKLE (sunucuda .env veya Render env):
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

MAKRO_API_URL=https://options-desk.vercel.app/api/macro?module=all

(options-desk.vercel.app yerine kendi Vercel URL'nizi yazın)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
4. PIP KURULUMU (requests zaten kuruluysa gerekmez):
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

pip install requests

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
KANAL YAPISI (bot.txt'den alınan gerçek değerler):
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Opsiyon Alarmları → chat_id=-1003896040852  thread_id=2
Makro Alarmları   → chat_id=-1003896040852  thread_id=7

(mevcut botunuzda -1002142274543 ve -1003896040852 kullanılıyor,
 yeni alarmlar sadece -1003896040852'ye gidecek)
"""
