// ═══════════════════════════════════════════════════════════
// Telegram Gönderici — Ortak Yardımcı Modül
// Ortam değişkenleri (Vercel Dashboard → Settings → Environment):
//   TELEGRAM_BOT_TOKEN  : BotFather'dan alınan token
//   TELEGRAM_CHANNEL_ID : Kanal ID'si (örn: -1001234567890)
// ═══════════════════════════════════════════════════════════

const TG_API = "https://api.telegram.org";

// ─── Markdown formatında mesaj gönder ─────────────────────
export async function tgGonder(mesaj, parse_mode = "HTML") {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  const chatId = process.env.TELEGRAM_CHANNEL_ID;

  if (!token || !chatId) {
    console.warn("[TG] TELEGRAM_BOT_TOKEN veya TELEGRAM_CHANNEL_ID tanımlı değil");
    return { ok: false, hata: "Telegram ortam değişkenleri eksik" };
  }

  try {
    const r = await fetch(`${TG_API}/bot${token}/sendMessage`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        chat_id: chatId,
        text: mesaj,
        parse_mode,
        disable_web_page_preview: true,
      }),
      signal: AbortSignal.timeout(8000),
    });
    const d = await r.json();
    if (!d.ok) console.error("[TG] Gönderim hatası:", d.description);
    return d;
  } catch (e) {
    console.error("[TG] Fetch hatası:", e.message);
    return { ok: false, hata: e.message };
  }
}

// ─── Test endpoint ────────────────────────────────────────
export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ hata: "Sadece POST" });
  const { mesaj } = req.body || {};
  if (!mesaj) return res.status(400).json({ hata: "mesaj gerekli" });
  const sonuc = await tgGonder(mesaj);
  return res.status(sonuc.ok ? 200 : 500).json(sonuc);
}
