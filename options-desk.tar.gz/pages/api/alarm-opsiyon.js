// ═══════════════════════════════════════════════════════════
// Opsiyon Alarm Hesaplama API — Vercel Tarafı
//
// MİMARİ:
//   Python (opsiyon_alarm.py)
//     → GET /api/alarm-opsiyon          (her 15 dk)
//     → Vercel burada hesaplar (GEX, ZG, CW, PW, Spike)
//     → Tetiklenen alarmların mesajlarını döner
//     → Python Telegram'a iletir
//
// Bu sayede:
//   • lib/gex.js güncellenince otomatik devreye girer
//   • Hesaplama mantığı tek yerde (Vercel)
//   • Python sadece delivery yapar
//
// Alarm Tetikleyicileri:
//   1. Hacim Spike  — 0-7g OI ortalamanın 2.5x'i
//   2. Zero Gamma   — Spot %0.5 yakınlık
//   3. Call Wall    — Spot %0.3 yakınlık (üstünde)
//   4. Put Wall     — Spot %0.3 yakınlık (altında)
// ═══════════════════════════════════════════════════════════

// Vercel serverless: GEX modüllerini içe al
// (gex.js ile aynı hesaplamalar — lib import yerine inline)
// Not: Next.js API route'ları ES modules destekler

const HDR = { "Accept": "application/json", "User-Agent": "OpsiyonMasasi/1.0" };
const TO  = 12000;

// ─── Matematiksel Yardımcılar (lib/gex.js ile aynı) ───────
function normPDF(x) { return Math.exp(-0.5*x*x)/Math.sqrt(2*Math.PI); }
function normCDF(x) {
  const sign=x<0?-1:1; x=Math.abs(x);
  const t=1/(1+0.2316419*x);
  const p=t*(0.319381530+t*(-0.356563782+t*(1.781477937+t*(-1.821255978+t*1.330274429))));
  return 0.5+sign*(0.5-normPDF(Math.abs(x))*p);
}

// ─── Deribit API ──────────────────────────────────────────
async function deribit(method, params = {}) {
  const qs = new URLSearchParams(params).toString();
  const url = `https://www.deribit.com/api/v2/public/${method}${qs?"?"+qs:""}`;
  try {
    const r = await fetch(url, { headers: HDR, signal: AbortSignal.timeout(TO) });
    if (!r.ok) return null;
    const d = await r.json();
    return d.result;
  } catch(e) { return null; }
}

// ─── Spot Fiyat ───────────────────────────────────────────
async function spotAl() {
  const d = await deribit("get_index_price", { index_name: "btc_usd" });
  return parseFloat(d?.index_price || 0);
}

// ─── 0-7 Günlük Opsiyonlar ───────────────────────────────
async function kisaVadeliOpsiyonlar(spot) {
  const enstrumanlar = await deribit("get_instruments", {
    currency: "BTC", kind: "option", expired: "false"
  });
  if (!enstrumanlar?.length) return [];

  const now_ms      = Date.now();
  const yediGun_ms  = 7 * 24 * 3600 * 1000;
  const bugunStr    = new Date().toISOString().slice(0,10).replace(/-/g,"");

  const kisa = enstrumanlar.filter(i =>
    i.expiration_timestamp > now_ms &&
    (i.expiration_timestamp - now_ms) <= yediGun_ms
  ).slice(0, 30);

  const sonuclar = [];
  for (const inst of kisa) {
    const t = await deribit("ticker", { instrument_name: inst.instrument_name });
    if (!t || !t.open_interest) continue;
    sonuclar.push({
      anahtarId: `${bugunStr}_${inst.strike}_${inst.option_type}`,
      inst:      inst.instrument_name,
      strike:    inst.strike,
      tip:       inst.option_type,
      oi:        parseFloat(t.open_interest || 0),
      iv:        parseFloat(t.mark_iv || 0),
      vadGun:    Math.round((inst.expiration_timestamp - now_ms) / 86400000 * 10) / 10,
    });
    await new Promise(r => setTimeout(r, 60)); // rate limit
  }
  return sonuclar;
}

// ─── Key Seviyeler (GEX bazlı CW/PW/ZG) ──────────────────
async function keySeviyeleriHesapla(spot) {
  const enstrumanlar = await deribit("get_instruments", {
    currency: "BTC", kind: "option", expired: "false"
  });
  if (!enstrumanlar?.length || !spot) return null;

  const now_ms = Date.now();
  const strikeMap = {};

  // Tüm vadelerdeki GEX'i topla
  for (const inst of enstrumanlar.slice(0, 80)) {
    const t = await deribit("ticker", { instrument_name: inst.instrument_name });
    if (!t) continue;

    const k          = inst.strike;
    const oi         = parseFloat(t.open_interest || 0);
    const iv         = parseFloat(t.mark_iv || 50) / 100;
    const tip        = inst.option_type;
    const T          = Math.max((inst.expiration_timestamp - now_ms) / (365.25*24*3600*1000), 0.0001);
    const sqrtT      = Math.sqrt(T);

    if (!strikeMap[k]) strikeMap[k] = { callGex: 0, putGex: 0, callOI: 0, putOI: 0 };

    // Hull formülü: Γ = N'(d1)×e^(-qT) / (S×σ×√T)
    const d1   = (Math.log(spot/k) + 0.5*iv*iv*T) / (iv*sqrtT);
    const gamma = normPDF(d1) / (spot * iv * sqrtT);

    // GEX = γ × OI × S² × 0.01 × sign
    const gex = gamma * oi * spot * spot * 0.01;

    if (tip === "call") {
      strikeMap[k].callGex += gex;
      strikeMap[k].callOI  += oi;
    } else {
      strikeMap[k].putGex  -= gex;
      strikeMap[k].putOI   += oi;
    }
    await new Promise(r => setTimeout(r, 40));
  }

  if (!Object.keys(strikeMap).length) return null;

  // Call Wall: max pozitif GEX
  const callWall = Object.entries(strikeMap)
    .reduce((best,[k,v]) => v.callGex > best.gex ? {k:parseFloat(k), gex:v.callGex} : best,
            {k:0, gex:-Infinity}).k;

  // Put Wall: max negatif GEX (en negatif)
  const putWall = Object.entries(strikeMap)
    .reduce((best,[k,v]) => v.putGex < best.gex ? {k:parseFloat(k), gex:v.putGex} : best,
            {k:0, gex:Infinity}).k;

  // Zero Gamma: net GEX sıfıra en yakın strike
  const zeroGamma = Object.entries(strikeMap)
    .reduce((best,[k,v]) => {
      const net = Math.abs(v.callGex + v.putGex);
      return net < best.net ? {k:parseFloat(k), net} : best;
    }, {k:0, net:Infinity}).k;

  return { callWall, putWall, zeroGamma };
}

// ─── Mesaj Formatları ────────────────────────────────────
const fmtN = n => Math.round(n).toLocaleString("en-US");
const fmtP = (n,d=2) => `${n>=0?"+":""}${n.toFixed(d)}%`;

function hacimSpikeMesaji(sp, ortalama, spot, zaman) {
  const tip = sp.tip === "call" ? "📗 CALL" : "📕 PUT";
  const oran = (sp.oi / ortalama).toFixed(1);
  return (
    `⚡ <b>HACİM SPİKE — 0-7g BTC Opsiyonu</b>\n` +
    `━━━━━━━━━━━━━━━━━━━━━\n` +
    `${tip} | Strike: <b>$${fmtN(sp.strike)}</b>\n` +
    `Vade: <b>${sp.vadGun} gün</b>\n` +
    `Açık Pozisyon: <b>${fmtN(sp.oi)} BTC</b>\n` +
    `Ortalama: ${fmtN(ortalama)} BTC — Eşik: ${fmtN(ortalama*2.5)} BTC\n` +
    `Oran: <b>${oran}x</b> ortalama\n` +
    `IV: ${sp.iv.toFixed(1)}%\n` +
    `Spot: <b>$${fmtN(spot)}</b>\n\n` +
    `📊 <b>Hull Analizi (Bölüm 18):</b>\n` +
    `Kısa vadeli opsiyonda olağandışı OI birikimi. ` +
    `Vadeye yakın yüksek OI = güçlü pin riski. ` +
    `Dealer'lar bu strike'ta delta hedge baskısı oluşturur.\n\n` +
    `<i>${zaman}</i>`
  );
}

function zeroGammaMesaji(spot, zg, uzaklik, zaman) {
  const yon = spot > zg ? "ÜSTÜNDE ↑" : "ALTINDA ↓";
  return (
    `🔶 <b>ZERO GAMMA TEMASINDA — BTC</b>\n` +
    `━━━━━━━━━━━━━━━━━━━━━\n` +
    `Spot: <b>$${fmtN(spot)}</b>\n` +
    `Zero Gamma: <b>$${fmtN(zg)}</b>\n` +
    `Uzaklık: <b>${uzaklik.toFixed(2)}%</b> — Spot ZG ${yon}\n\n` +
    `📊 <b>Hull Analizi (Bölüm 19.6):</b>\n` +
    `Zero Gamma dealer gamma rejiminin kırılma noktasıdır.\n` +
    `• Spot ZG üstü → Dealer long gamma → Mean-reversion baskısı\n` +
    `• Spot ZG altı → Dealer short gamma → Momentum / Vol artışı\n\n` +
    `⚡ Bu seviye kırılırsa volatilite amplifikasyonu beklenir.\n\n` +
    `<i>${zaman}</i>`
  );
}

function callWallMesaji(spot, cw, uzaklik, zaman) {
  return (
    `📗 <b>CALL WALL TEMASINDA — BTC</b>\n` +
    `━━━━━━━━━━━━━━━━━━━━━\n` +
    `Spot: <b>$${fmtN(spot)}</b>\n` +
    `Call Wall: <b>$${fmtN(cw)}</b>\n` +
    `Uzaklık: <b>${fmtP(uzaklik)}</b>\n\n` +
    `📊 <b>Hull Analizi (Bölüm 19.5):</b>\n` +
    `Call Wall = maksimum pozitif gamma yoğunlaşması.\n` +
    `• Dealer burada delta satışı başlatır\n` +
    `• Spot'un CW'u kırması zor — güçlü direnç\n` +
    `• Kırılım → short squeeze + gamma squeeze riski\n\n` +
    `<i>${zaman}</i>`
  );
}

function putWallMesaji(spot, pw, uzaklik, zaman) {
  return (
    `📕 <b>PUT WALL TEMASINDA — BTC</b>\n` +
    `━━━━━━━━━━━━━━━━━━━━━\n` +
    `Spot: <b>$${fmtN(spot)}</b>\n` +
    `Put Wall: <b>$${fmtN(pw)}</b>\n` +
    `Uzaklık: <b>${fmtP(uzaklik)}</b>\n\n` +
    `📊 <b>Hull Analizi (Bölüm 19.5):</b>\n` +
    `Put Wall = maksimum negatif gamma yoğunlaşması.\n` +
    `• Dealer burada delta alımı başlatır (destek)\n` +
    `• Kırılım → gamma negatife döner, vol genişler\n` +
    `• Hızlı aşağı hareket riski artar\n\n` +
    `<i>${zaman}</i>`
  );
}

// ─── ANA HANDLER ──────────────────────────────────────────
export default async function handler(req, res) {
  // Sadece GET isteği
  if (req.method !== "GET" && req.method !== "POST") {
    return res.status(405).json({ hata: "GET veya POST gerekli" });
  }

  const zaman = new Date().toLocaleString("tr-TR", {
    timeZone: "UTC",
    day: "2-digit", month: "2-digit", year: "numeric",
    hour: "2-digit", minute: "2-digit",
  }) + " UTC";

  try {
    // 1. Spot fiyat
    const spot = await spotAl();
    if (!spot) {
      return res.status(503).json({ hata: "Spot fiyat alınamadı" });
    }

    // 2. Paralel: kısa vadeli opsiyonlar + key seviyeler
    // (Not: Vercel timeout 10s — seviyeler ağır, sadece spike paralel)
    const opsiyonlar = await kisaVadeliOpsiyonlar(spot);

    // Tetiklenen alarmların listesi — Python bu listeyi alıp Telegram'a gönderir
    const alarmlar = [];

    // ── Alarm 1: Hacim Spike ────────────────────────────
    if (opsiyonlar.length >= 3) {
      const oiListesi = opsiyonlar.map(o => o.oi).filter(v => v > 0);
      if (oiListesi.length) {
        const ortalama = oiListesi.reduce((a,b) => a+b, 0) / oiListesi.length;
        const esik     = ortalama * 2.5;
        const spikeler = opsiyonlar
          .filter(o => o.oi >= esik)
          .sort((a,b) => b.oi - a.oi)
          .slice(0, 3);

        for (const sp of spikeler) {
          alarmlar.push({
            tip:     "hacim_spike",
            anahtar: `spike_${sp.anahtarId}`,
            mesaj:   hacimSpikeMesaji(sp, ortalama, spot, zaman),
          });
        }
      }
    }

    // ── Alarmlar 2-4: Key Seviyeler ─────────────────────
    // Seviyeler hesaplaması ağır (60+ ticker çağrısı)
    // Sadece istek parametresi varsa hesapla (Python saatlik gönderir)
    const seviyeIste = req.query.seviye === "1" || req.body?.seviye === true;

    if (seviyeIste) {
      const seviyeler = await keySeviyeleriHesapla(spot);

      if (seviyeler) {
        const { callWall, putWall, zeroGamma } = seviyeler;

        // Zero Gamma
        if (zeroGamma) {
          const uzaklik = Math.abs((spot - zeroGamma) / spot * 100);
          if (uzaklik <= 0.5) {
            alarmlar.push({
              tip:     "zero_gamma",
              anahtar: "zero_gamma",
              mesaj:   zeroGammaMesaji(spot, zeroGamma, uzaklik, zaman),
            });
          }
        }

        // Call Wall
        if (callWall) {
          const uzaklik = (callWall - spot) / spot * 100;
          if (uzaklik >= 0 && uzaklik <= 0.3) {
            alarmlar.push({
              tip:     "call_wall",
              anahtar: "call_wall",
              mesaj:   callWallMesaji(spot, callWall, uzaklik, zaman),
            });
          }
        }

        // Put Wall
        if (putWall) {
          const uzaklik = (spot - putWall) / spot * 100;
          if (uzaklik >= 0 && uzaklik <= 0.3) {
            alarmlar.push({
              tip:     "put_wall",
              anahtar: "put_wall",
              mesaj:   putWallMesaji(spot, putWall, uzaklik, zaman),
            });
          }
        }
      }
    }

    res.setHeader("Cache-Control", "no-store"); // Canlı veri — cache'leme
    return res.status(200).json({
      timestamp:      new Date().toISOString(),
      spot,
      opsiyon_sayisi: opsiyonlar.length,
      alarmlar,       // Python bunu okur, Telegram'a iletir
    });

  } catch (e) {
    console.error("[alarm-opsiyon]", e);
    return res.status(500).json({ hata: e.message });
  }
}
