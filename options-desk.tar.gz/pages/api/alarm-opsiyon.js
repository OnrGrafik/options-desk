// ═══════════════════════════════════════════════════════════
// Opsiyon Alarm API
// Her 15 dakikada bir Vercel Cron tarafından çağrılır
// Tetikleyiciler:
//   1. Hacim Spike — 0-7g seçeneklerinde son OI ortalamanın 2x'i
//   2. Zero Gamma Teması — spot %0.5 yakınlık
//   3. Call Wall Teması — spot %0.3 yakınlık
//   4. Put Wall Teması — spot %0.3 yakınlık
// ═══════════════════════════════════════════════════════════

import { tgGonder } from "./telegram";

// Son alarmları hafızada tut — aynı alarmı tekrar gönderme
// (Vercel serverless'ta her çağrıda sıfırlanır ama
//  kısa süre içinde art arda tetiklenmeyi önler)
const ALARM_BELLEK = {};
const ALARM_SESSIZ_SURESI = 30 * 60 * 1000; // 30 dakika

function alarmGonderildiMi(anahtar) {
  const son = ALARM_BELLEK[anahtar];
  if (!son) return false;
  return (Date.now() - son) < ALARM_SESSIZ_SURESI;
}
function alarmKaydet(anahtar) {
  ALARM_BELLEK[anahtar] = Date.now();
}

// ─── Deribit'ten veri çek ─────────────────────────────────
async function deribitCag(method, params = "") {
  const base = "https://www.deribit.com/api/v2/public";
  const url = `${base}/${method}?${params}`;
  const r = await fetch(url, {
    headers: { "Accept": "application/json" },
    signal: AbortSignal.timeout(10000),
  });
  if (!r.ok) throw new Error(`Deribit HTTP ${r.status}`);
  const d = await r.json();
  return d.result;
}

async function spotFiyat() {
  const d = await deribitCag("get_index_price", "index_name=btc_usd");
  return d?.index_price || 0;
}

// 0-7 günlük opsiyonları çek
async function kısaVadeli0_7() {
  const enstrumanlar = await deribitCag("get_instruments", "currency=BTC&kind=option&expired=false");
  if (!enstrumanlar?.length) return [];

  const now = Date.now();
  const yedi_gun = 7 * 24 * 3600 * 1000;

  const kisaVadeli = enstrumanlar.filter(i =>
    (i.expiration_timestamp - now) <= yedi_gun &&
    i.expiration_timestamp > now
  );

  if (!kisaVadeli.length) return [];

  // Batch ticker çek (en fazla 20)
  const ornekler = kisaVadeli.slice(0, 20);
  const tickerler = await Promise.allSettled(
    ornekler.map(i =>
      deribitCag("ticker", `instrument_name=${i.instrument_name}`)
        .then(t => ({ inst: i.instrument_name, oi: t?.open_interest || 0, iv: t?.mark_iv || 0, strike: i.strike, type: i.option_type }))
        .catch(() => null)
    )
  );

  return tickerler
    .filter(r => r.status === "fulfilled" && r.value)
    .map(r => r.value);
}

// ─── Alarm kontrolleri ────────────────────────────────────

// 1. Hacim Spike — OI ortalamanın 2.5 katı üstü
function hacimSpikeKontrol(opsiyonlar) {
  if (!opsiyonlar.length) return null;
  const oiDegerleri = opsiyonlar.map(o => o.oi).filter(v => v > 0);
  if (!oiDegerleri.length) return null;

  const ortalama = oiDegerleri.reduce((a, b) => a + b, 0) / oiDegerleri.length;
  const esik = ortalama * 2.5;

  const spike = opsiyonlar
    .filter(o => o.oi > esik)
    .sort((a, b) => b.oi - a.oi)[0];

  if (!spike) return null;
  return {
    tip: "hacim_spike",
    mesaj: spike,
    ortalama: Math.round(ortalama),
    esik: Math.round(esik),
  };
}

// 2. Zero Gamma yakınlık (%0.5)
function zeroGammaKontrol(spot, zeroGamma) {
  if (!zeroGamma || !spot) return null;
  const uzaklik = Math.abs((spot - zeroGamma) / spot * 100);
  if (uzaklik <= 0.5) return { tip: "zero_gamma", uzaklik, zeroGamma };
  return null;
}

// 3. Call Wall yakınlık (%0.3)
function callWallKontrol(spot, callWall) {
  if (!callWall || !spot) return null;
  const uzaklik = (callWall - spot) / spot * 100;
  if (uzaklik >= 0 && uzaklik <= 0.3) return { tip: "call_wall", uzaklik, callWall };
  return null;
}

// 4. Put Wall yakınlık (%0.3)
function putWallKontrol(spot, putWall) {
  if (!putWall || !spot) return null;
  const uzaklik = (spot - putWall) / spot * 100;
  if (uzaklik >= 0 && uzaklik <= 0.3) return { tip: "put_wall", uzaklik, putWall };
  return null;
}

// ─── Telegram mesaj formatları ───────────────────────────

function fmt(n) {
  return n ? Math.round(n).toLocaleString("tr-TR") : "—";
}
function fmtPct(n, digits = 2) {
  return n != null ? `${n >= 0 ? "+" : ""}${n.toFixed(digits)}%` : "—";
}

function hacimSpikeMesaji(alarm, spot) {
  const o = alarm.mesaj;
  const tip = o.type === "call" ? "📗 CALL" : "📕 PUT";
  return `
⚡ <b>HACİM SPİKE — 0-7g BTC Opsiyonu</b>

${tip} OPSİYON — Strike: <b>$${fmt(o.strike)}</b>
Açık Pozisyon: <b>${fmt(o.oi)} BTC</b>
Ortalama: ${fmt(alarm.ortalama)} BTC (eşik: ${fmt(alarm.esik)})
Oran: ${(o.oi / alarm.ortalama).toFixed(1)}x ortalama
IV: ${o.iv ? o.iv.toFixed(1) + "%" : "—"}
Spot: $${fmt(spot)}
Spot → Strike: ${fmtPct((o.strike - spot) / spot * 100)}

⚠️ Kısa vadeli opsiyonda olağandışı pozisyon birikimi.
Hull (Bölüm 18): Vadeye yakın yüksek OI — pin riski artar.
`.trim();
}

function zeroGammaMesaji(alarm, spot, hullYorum) {
  const yon = spot > alarm.zeroGamma ? "ÜSTÜNDE (long gamma bölge)" : "ALTINDA (short gamma bölge)";
  return `
🔶 <b>ZERO GAMMA TEMASINDA — BTC Opsiyon Masası</b>

Spot: <b>$${fmt(spot)}</b>
Zero Gamma: <b>$${fmt(alarm.zeroGamma)}</b>
Uzaklık: <b>${alarm.uzaklik.toFixed(2)}%</b> — Spot ZG'nin ${yon}

📊 <b>Hull Analizi (Bölüm 19.6):</b>
Zero Gamma seviyesi dealer gamma rejiminin flip noktasıdır.
• Spot ZG üstünde → Dealer long gamma → Mean-reversion baskısı
• Spot ZG altına düşerse → Dealer short gamma → Momentum güçlenir, vol artar

⚡ Dikkat: Bu seviye kırılırsa volatilite amplifikasyonu beklenir.
`.trim();
}

function callWallMesaji(alarm, spot) {
  return `
📗 <b>CALL WALL TEMASINDA — BTC Opsiyon Masası</b>

Spot: <b>$${fmt(spot)}</b>
Call Wall: <b>$${fmt(alarm.callWall)}</b>
Uzaklık: <b>${alarm.uzaklik.toFixed(2)}%</b>

📊 <b>Hull Analizi (Bölüm 19.5):</b>
Call Wall maksimum pozitif gamma yoğunlaşma noktasıdır.
• Dealer burada delta satışı başlatır (mean-reversion)
• Kırılım halinde short squeeze ve gamma squeeze riski var
• Call Wall üstü kapanış → yeni direnç bölgesi aranır

⚡ Kısa vadeli opsiyonlarda pin baskısı güçlenir.
`.trim();
}

function putWallMesaji(alarm, spot) {
  return `
📕 <b>PUT WALL TEMASINDA — BTC Opsiyon Masası</b>

Spot: <b>$${fmt(spot)}</b>
Put Wall: <b>$${fmt(alarm.putWall)}</b>
Uzaklık: <b>${alarm.uzaklik.toFixed(2)}%</b>

📊 <b>Hull Analizi (Bölüm 19.5):</b>
Put Wall maksimum negatif gamma yoğunlaşma noktasıdır.
• Dealer burada delta alımı başlatır (destek etkisi)
• Kırılım halinde gamma negatife döner, vol genişler
• Put Wall altı kapanış → hızlı aşağı hareket riski

⚡ Spot bu seviyeye gelince dealer hedging desteği azalır.
`.trim();
}

// ─── ANA HANDLER ──────────────────────────────────────────
export default async function handler(req, res) {
  // Sadece Vercel Cron veya yetkili çağrıya izin ver
  const cronSecret = process.env.CRON_SECRET;
  if (cronSecret && req.headers["x-cron-secret"] !== cronSecret) {
    if (req.method === "POST" && req.body?.test) {
      // Test modu — secret olmasa da izin ver
    } else {
      return res.status(401).json({ hata: "Yetkisiz" });
    }
  }

  const gonderilen = [];
  const hatalar = [];

  try {
    // Spot ve opsiyonları paralel çek
    const [spot, opsiyonlar] = await Promise.all([
      spotFiyat(),
      kısaVadeli0_7(),
    ]);

    if (!spot) {
      return res.status(503).json({ hata: "Spot fiyat alınamadı" });
    }

    // Alarm parametrelerini environment'tan al (Vercel dashboard'dan girilir)
    const zeroGamma = parseFloat(process.env.ZERO_GAMMA_SEVIYE || "0") || null;
    const callWall  = parseFloat(process.env.CALL_WALL_SEVIYE  || "0") || null;
    const putWall   = parseFloat(process.env.PUT_WALL_SEVIYE   || "0") || null;
    // Not: Bu seviyeler front-end'den POST ile de güncellenebilir

    // ── Kontrol 1: Hacim Spike
    const hacimAlarm = hacimSpikeKontrol(opsiyonlar);
    if (hacimAlarm && !alarmGonderildiMi(`spike_${hacimAlarm.mesaj.inst}`)) {
      const tgMesaj = hacimSpikeMesaji(hacimAlarm, spot);
      const sonuc = await tgGonder(tgMesaj);
      if (sonuc.ok) {
        alarmKaydet(`spike_${hacimAlarm.mesaj.inst}`);
        gonderilen.push({ tip: "hacim_spike", inst: hacimAlarm.mesaj.inst });
      } else {
        hatalar.push({ tip: "hacim_spike", hata: sonuc.description });
      }
    }

    // ── Kontrol 2: Zero Gamma
    if (zeroGamma) {
      const zgAlarm = zeroGammaKontrol(spot, zeroGamma);
      if (zgAlarm && !alarmGonderildiMi("zero_gamma")) {
        const tgMesaj = zeroGammaMesaji(zgAlarm, spot);
        const sonuc = await tgGonder(tgMesaj);
        if (sonuc.ok) {
          alarmKaydet("zero_gamma");
          gonderilen.push({ tip: "zero_gamma" });
        } else {
          hatalar.push({ tip: "zero_gamma", hata: sonuc.description });
        }
      }
    }

    // ── Kontrol 3: Call Wall
    if (callWall) {
      const cwAlarm = callWallKontrol(spot, callWall);
      if (cwAlarm && !alarmGonderildiMi("call_wall")) {
        const tgMesaj = callWallMesaji(cwAlarm, spot);
        const sonuc = await tgGonder(tgMesaj);
        if (sonuc.ok) {
          alarmKaydet("call_wall");
          gonderilen.push({ tip: "call_wall" });
        } else {
          hatalar.push({ tip: "call_wall", hata: sonuc.description });
        }
      }
    }

    // ── Kontrol 4: Put Wall
    if (putWall) {
      const pwAlarm = putWallKontrol(spot, putWall);
      if (pwAlarm && !alarmGonderildiMi("put_wall")) {
        const tgMesaj = putWallMesaji(pwAlarm, spot);
        const sonuc = await tgGonder(tgMesaj);
        if (sonuc.ok) {
          alarmKaydet("put_wall");
          gonderilen.push({ tip: "put_wall" });
        } else {
          hatalar.push({ tip: "put_wall", hata: sonuc.description });
        }
      }
    }

    return res.status(200).json({
      kontrol_edildi: new Date().toISOString(),
      spot,
      opsiyon_sayisi: opsiyonlar.length,
      gonderilen,
      hatalar: hatalar.length ? hatalar : undefined,
    });

  } catch (e) {
    console.error("[Opsiyon Alarm]", e);
    return res.status(500).json({ hata: e.message });
  }
}
