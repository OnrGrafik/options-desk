// ═══════════════════════════════════════════════════════════
// Makro Alarm API
// Her gün 09:00 UTC'de Vercel Cron tarafından çağrılır
// Önceki değerlerle karşılaştırır, önemli değişimde Telegram gönderir
// Değişim eşikleri:
//   CPI    : ±0.5 puan
//   NFP    : ±30K
//   PPI    : ±0.3% aylık
//   İşsizlik: ±0.1%
//   ISM    : ±1.0 puan
//   Perakende: ±0.5%
// ═══════════════════════════════════════════════════════════

import { tgGonder } from "./telegram";

// ─── Önceki değerleri hafızada tut ───────────────────────
// Vercel serverless'ta kalıcı değil — .env veya KV store kullanılabilir
// Basit çözüm: vercel'in edge config veya ortam değişkenleri
let ONCEKI_VERILER = {};

const ESIKLER = {
  cpi:           0.5,   // endeks puanı
  nfp:           30,    // bin kişi
  ppi:           0.3,   // aylık % değişim puanı
  iscabasvurusu: 0.1,   // işsizlik oranı %
  ismImalat:     1.0,   // PMI puanı
  perakende:     3.0,   // milyar $ fark
  gsyih:         0.3,   // büyüme % farkı
  pce:           0.3,   // büyüme % farkı
  fedFaiz:       0.1,   // faiz % farkı
};

const GOSTARCI_ISIMLER = {
  fedFaiz:       "Fed Faiz / Hazine Bonosu",
  cpi:           "TÜFE (CPI Endeksi)",
  nfp:           "Tarım Dışı İstihdam (NFP)",
  ppi:           "ÜFE (PPI Aylık %)",
  iscabasvurusu: "İşsizlik Oranı",
  gsyih:         "GSYİH Büyüme",
  pce:           "PCE Tüketim",
  ismImalat:     "ISM İmalat PMI",
  perakende:     "Perakende Satışlar",
};

const GOSTARCI_BIRIM = {
  fedFaiz:       "%",
  cpi:           "",
  nfp:           "K",
  ppi:           "%",
  iscabasvurusu: "%",
  gsyih:         "%",
  pce:           "%",
  ismImalat:     "",
  perakende:     " Mr$",
};

// ─── Makro verileri çek ────────────────────────────────────
async function makroVeriCek() {
  const BASE = process.env.VERCEL_URL
    ? `https://${process.env.VERCEL_URL}`
    : "http://localhost:3000";

  const r = await fetch(`${BASE}/api/macro?module=all`, {
    signal: AbortSignal.timeout(30000),
  });
  if (!r.ok) throw new Error(`Makro API ${r.status}`);
  return r.json();
}

// ─── Değişim tespiti ──────────────────────────────────────
function degisimTespit(anahtar, guncel, onceki) {
  if (guncel == null || onceki == null) return false;
  const fark = Math.abs(guncel - onceki);
  const esik = ESIKLER[anahtar] || 0.1;
  return fark >= esik;
}

// ─── Telegram mesaj formatı ───────────────────────────────
function makroTelegramMesaji(gostergeler, btcYorum, degisimler) {
  const zaman = new Date().toLocaleString("tr-TR", {
    timeZone: "UTC",
    day: "numeric", month: "long", hour: "2-digit", minute: "2-digit",
  });

  // Başlık
  const sentez = btcYorum?.sentez || "";
  const genelDurum =
    sentez.includes("OLUMLU") ? "📗 OLUMLU" :
    sentez.includes("OLUMSUZ") ? "📕 OLUMSUZ" : "📙 NÖTR";

  // Değişen göstergeler tablosu
  const satirlar = degisimler.map(({ anahtar, eskiDeger, yeniDeger }) => {
    const isim  = GOSTARCI_ISIMLER[anahtar] || anahtar;
    const birim = GOSTARCI_BIRIM[anahtar] || "";
    const fark  = yeniDeger - eskiDeger;
    const isaret = fark > 0 ? "▲" : "▼";
    const renk  = fark > 0 ? "+" : "";
    const fmt = (n) => n != null ? `${n.toLocaleString("tr-TR", { maximumFractionDigits: 2 })}${birim}` : "—";
    return `• <b>${isim}</b>: ${fmt(yeniDeger)} (önceki: ${fmt(eskiDeger)}) ${isaret} <i>${renk}${Math.abs(fark).toFixed(2)}${birim}</i>`;
  });

  // BTC yorumları (değişen göstergeler için)
  const yorumlar = degisimler
    .map(({ anahtar }) => btcYorum?.yorumHarita?.[anahtar])
    .filter(Boolean)
    .slice(0, 3);

  let mesaj = `
🔔 <b>MAKRO VERİ DEĞİŞİKLİĞİ — ${zaman} UTC</b>

<b>Genel BTC Görünümü: ${genelDurum}</b>

📊 <b>Değişen Göstergeler:</b>
${satirlar.join("\n")}
`.trim();

  if (yorumlar.length) {
    mesaj += `\n\n💬 <b>BTC Etkisi:</b>\n${yorumlar.map(y => `• ${y}`).join("\n\n")}`;
  }

  mesaj += `\n\n<i>Opsiyon Masası Makro Modülü · ${zaman}</i>`;
  return mesaj;
}

// ─── Tüm veri tablosu (günlük özet) ─────────────────────
function gunlukOzetMesaji(gostergeler, btcYorum) {
  const zaman = new Date().toLocaleString("tr-TR", {
    timeZone: "UTC",
    day: "numeric", month: "long", year: "numeric", hour: "2-digit", minute: "2-digit",
  });
  const sentez = btcYorum?.sentez || "";
  const g = gostergeler;

  const fmt = (veri, birim = "") => {
    if (!veri?.guncel && veri?.guncel !== 0) return "—";
    return `${veri.guncel.toLocaleString("tr-TR", { maximumFractionDigits: 2 })}${birim}`;
  };
  const deg = (veri, birim = "") => {
    if (veri?.degisim == null) return "";
    const d = veri.degisim;
    return ` (${d >= 0 ? "+" : ""}${d.toFixed(2)}${birim})`;
  };
  const trend = (veri) => {
    if (!veri?.trend) return "";
    return veri.trend === "yukari" ? " ▲" : veri.trend === "asagi" ? " ▼" : " →";
  };

  return `
📋 <b>GÜNLÜK MAKRO ÖZET — ${zaman} UTC</b>

${sentez}

<b>📈 Gösterge Tablosu:</b>
┌─────────────────────────────────┐
│ Fed Faiz   : ${fmt(g.fedFaiz,"%")}${deg(g.fedFaiz,"%")}${trend(g.fedFaiz)}
│ TÜFE (CPI) : ${fmt(g.cpi)}${deg(g.cpi)}${trend(g.cpi)}
│ NFP        : ${fmt(g.nfp,"K")}${deg(g.nfp,"K")}${trend(g.nfp)}
│ ÜFE (PPI)  : ${fmt(g.ppi,"%")}${deg(g.ppi,"%")}${trend(g.ppi)}
│ İşsizlik   : ${fmt(g.iscabasvurusu,"%")}${deg(g.iscabasvurusu,"%")}${trend(g.iscabasvurusu)}
│ GSYİH      : ${fmt(g.gsyih,"%")}${deg(g.gsyih,"%")}${trend(g.gsyih)}
│ PCE        : ${fmt(g.pce,"%")}${deg(g.pce,"%")}${trend(g.pce)}
│ ISM PMI    : ${fmt(g.ismImalat)}${deg(g.ismImalat)}${trend(g.ismImalat)}
│ Perakende  : ${fmt(g.perakende," Mr$")}${deg(g.perakende," Mr$")}${trend(g.perakende)}
└─────────────────────────────────┘

<b>🔍 BTC Yorumları:</b>
${[g.fedFaiz, g.cpi, g.nfp].map((_, i) => {
  const k = ["fedFaiz","cpi","nfp"][i];
  const y = btcYorum?.yorumHarita?.[k];
  return y ? `• ${y}` : null;
}).filter(Boolean).join("\n\n")}

<i>Opsiyon Masası · Makro Ekonomi Modülü</i>
`.trim();
}

// ─── ANA HANDLER ──────────────────────────────────────────
export default async function handler(req, res) {
  const cronSecret = process.env.CRON_SECRET;
  const mode = req.query.mode || req.body?.mode || "degisim";
  // mode: "degisim" | "gunluk_ozet" | "test"

  if (cronSecret && req.headers["x-cron-secret"] !== cronSecret) {
    if (mode !== "test") {
      return res.status(401).json({ hata: "Yetkisiz" });
    }
  }

  try {
    const veri = await makroVeriCek();
    const { gostergeler, btcYorum } = veri;

    // ── MOD: Günlük özet (her sabah tüm tabloyu gönder)
    if (mode === "gunluk_ozet") {
      const mesaj = gunlukOzetMesaji(gostergeler, btcYorum);
      const sonuc = await tgGonder(mesaj);
      return res.status(200).json({
        mod: "gunluk_ozet",
        gonderildi: sonuc.ok,
        hata: sonuc.ok ? undefined : sonuc.description,
      });
    }

    // ── MOD: Test (anında gönder, değişim kontrolü yapma)
    if (mode === "test") {
      const mesaj = gunlukOzetMesaji(gostergeler, btcYorum);
      const sonuc = await tgGonder(mesaj);
      return res.status(200).json({
        mod: "test",
        gonderildi: sonuc.ok,
        hata: sonuc.ok ? undefined : sonuc.description,
      });
    }

    // ── MOD: Değişim tespiti (varsayılan)
    const degisimler = [];

    Object.entries(gostergeler).forEach(([anahtar, vd]) => {
      if (!vd?.guncel && vd?.guncel !== 0) return;
      const onceki = ONCEKI_VERILER[anahtar];
      if (onceki != null && degisimTespit(anahtar, vd.guncel, onceki)) {
        degisimler.push({
          anahtar,
          eskiDeger: onceki,
          yeniDeger: vd.guncel,
        });
      }
      // Güncelle
      ONCEKI_VERILER[anahtar] = vd.guncel;
    });

    if (degisimler.length > 0) {
      const mesaj = makroTelegramMesaji(gostergeler, btcYorum, degisimler);
      const sonuc = await tgGonder(mesaj);
      return res.status(200).json({
        mod: "degisim",
        degisim_sayisi: degisimler.length,
        degisimler: degisimler.map(d => d.anahtar),
        gonderildi: sonuc.ok,
        hata: sonuc.ok ? undefined : sonuc.description,
      });
    }

    return res.status(200).json({
      mod: "degisim",
      degisim_sayisi: 0,
      mesaj: "Eşiği aşan değişiklik yok",
    });

  } catch (e) {
    console.error("[Makro Alarm]", e);
    return res.status(500).json({ hata: e.message });
  }
}
