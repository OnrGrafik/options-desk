"""
Makro Alarm Modülü v2
─────────────────────────────────────────────
Değişiklikler:
  - Değişim anında gönderilir (30 dakika polling, 4 saat bekleme yok)
  - Günlük özet kaldırıldı
  - Cuma 20:00 TR (17:00 UTC) haftalık özet gönderilir
  - Çift mesaj engeli: her gösterge için bağımsız bayrak
  - Aynı gösterge değişimi 24 saat içinde tekrar bildirilmez

Telegram: chat_id=-1003896040852  thread_id=7  (Makro kanalı)
Polling aralığı: 30 dakika
"""

import os
import time
import asyncio
import threading
import requests
from datetime import datetime, timezone
import pytz

# ─── Kanal & Timezone ────────────────────────────────────────
MAKRO_CHAT_ID   = -1003896040852
MAKRO_THREAD_ID = 7
TR_TZ           = pytz.timezone("Europe/Istanbul")

# ─── Eşikler ─────────────────────────────────────────────────
ESIKLER = {
    "fedFaiz":       0.10,
    "cpi":           0.50,
    "nfp":           30.0,
    "ppi":           0.30,
    "iscabasvurusu": 0.10,
    "ismImalat":     1.00,
    "perakende":     3.00,
    "gsyih":         0.30,
    "pce":           0.30,
}

ISIMLER = {
    "fedFaiz":       "Fed Faiz / Hazine Bonosu",
    "cpi":           "TÜFE (CPI Endeksi)",
    "nfp":           "Tarım Dışı İstihdam (NFP)",
    "ppi":           "ÜFE (PPI Aylık %)",
    "iscabasvurusu": "İşsizlik Oranı",
    "gsyih":         "GSYİH Büyüme",
    "pce":           "PCE Tüketim",
    "ismImalat":     "ISM İmalat PMI",
    "perakende":     "Perakende Satışlar",
}

BIRIMLER = {
    "fedFaiz":       "%",
    "cpi":           "",
    "nfp":           "K",
    "ppi":           "%",
    "iscabasvurusu": "%",
    "gsyih":         "%",
    "pce":           "%",
    "ismImalat":     "",
    "perakende":     " Mr$",
}

# ─── Hafıza ───────────────────────────────────────────────────
_onceki: dict      = {}   # {key: son_guncel_deger}
_alarm_ts: dict    = {}   # {key: son_alarm_unix_ts}  — 24 saat tekrar engeli
_bellek_lock       = threading.Lock()

# Haftalık özet — Cuma 20:00 TR'de bir kez gönderilir
_son_haftalik: str = ""   # "YYYY-WW" formatı

# ─── Gönderim Kilidi ──────────────────────────────────────────
_gonderim_lock = threading.Lock()


def _alarm_gonderildi_mi(key: str) -> bool:
    """Aynı gösterge için 24 saat içinde tekrar alarm gönderilmez."""
    with _bellek_lock:
        son = _alarm_ts.get(key, 0)
        return (time.time() - son) < 24 * 3600


def _alarm_kaydet(key: str):
    with _bellek_lock:
        _alarm_ts[key] = time.time()


# ─── Telegram ────────────────────────────────────────────────
async def _tg_gonder_async(mesaj: str):
    from telegram import Bot
    token = os.getenv("BOT_TOKEN")
    if not token:
        print("[MakroAlarm] BOT_TOKEN bulunamadı")
        return
    try:
        bot     = Bot(token=token)
        parcalar = [mesaj[i:i+4096] for i in range(0, len(mesaj), 4096)]
        for parca in parcalar:
            await bot.send_message(
                chat_id=MAKRO_CHAT_ID,
                text=parca,
                parse_mode="HTML",
                message_thread_id=MAKRO_THREAD_ID,
                disable_web_page_preview=True,
            )
            if len(parcalar) > 1:
                await asyncio.sleep(0.5)
        print(f"[MakroAlarm] ✓ Gönderildi ({len(parcalar)} parça)")
    except Exception as e:
        print(f"[MakroAlarm] Telegram hatası: {e}")


def _gonder(mesaj: str):
    """Thread-safe tekil gönderim."""
    with _gonderim_lock:
        try:
            loop = asyncio.new_event_loop()
            loop.run_until_complete(_tg_gonder_async(mesaj))
            loop.close()
        except Exception as e:
            print(f"[MakroAlarm] Gönderim hatası: {e}")


# ─── API ─────────────────────────────────────────────────────
MAKRO_API_URL = os.getenv(
    "MAKRO_API_URL",
    "https://options-desk.vercel.app/api/macro?module=all"
)


def _veri_cek() -> dict | None:
    try:
        r = requests.get(MAKRO_API_URL, timeout=30)
        r.raise_for_status()
        return r.json()
    except Exception as e:
        print(f"[MakroAlarm] API hatası: {e}")
        return None


# ─── Yardımcılar ─────────────────────────────────────────────
def _fmt(deger, birim: str) -> str:
    if deger is None:
        return "—"
    if birim == "K":
        return f"{deger:+.0f}{birim}"
    return f"{deger:.2f}{birim}"


def _trend(t: str) -> str:
    return {"yukari": "▲", "asagi": "▼", "sabit": "→"}.get(t or "", "—")


def _degisim_etiketi(key: str, fark: float, birim: str) -> str:
    """Artış mı iyi mi kötü mü? Göstergeye göre renk ver."""
    ters = key in {"cpi", "nfp", "ppi", "perakende"}
    isaretli = f"{fark:+.2f}{birim}"
    if abs(fark) < 0.001:
        return "→ Değişmedi"
    if (fark > 0) != ters:
        return f"✅ {isaretli} — olumlu"
    return f"⚠️ {isaretli} — dikkat"


# ─── Mesaj Formatları ────────────────────────────────────────
def _degisim_mesaji(degisimler: list, gostergeler: dict,
                    btcYorum: dict, zaman: str) -> str:
    sentez = (btcYorum or {}).get("sentez", "")
    genel  = (
        "📗 OLUMLU" if "OLUMLU"  in sentez else
        "📕 OLUMSUZ" if "OLUMSUZ" in sentez else
        "📙 NÖTR"
    )

    satirlar = []
    for d in degisimler:
        key   = d["key"]
        birim = BIRIMLER.get(key, "")
        fark  = d["yeni"] - d["eski"]
        etiket = _degisim_etiketi(key, fark, birim)
        satirlar.append(
            f"• <b>{ISIMLER.get(key, key)}</b>: "
            f"{_fmt(d['yeni'], birim)} "
            f"(önceki: {_fmt(d['eski'], birim)}) {etiket}"
        )

    yorumHarita = (btcYorum or {}).get("yorumHarita", {})
    btc_yorumlari = [
        f"• {yorumHarita[d['key']]}"
        for d in degisimler[:3]
        if yorumHarita.get(d["key"])
    ]

    mesaj = (
        f"🔔 <b>MAKRO VERİ DEĞİŞİKLİĞİ</b>\n"
        f"━━━━━━━━━━━━━━━━━━━━━\n"
        f"<b>Genel BTC Görünümü: {genel}</b>\n\n"
        f"📊 <b>Değişen Göstergeler ({len(degisimler)} adet):</b>\n"
        + "\n".join(satirlar)
    )
    if btc_yorumlari:
        mesaj += "\n\n💬 <b>BTC Etkisi:</b>\n" + "\n\n".join(btc_yorumlari)
    mesaj += f"\n\n<i>Opsiyon Masası · Makro Modülü · {zaman}</i>"
    return mesaj


def _haftalik_ozet_mesaji(gostergeler: dict, btcYorum: dict,
                           zaman: str, hafta: str) -> str:
    sentez = (btcYorum or {}).get("sentez", "")

    def _g(key, birim=""):
        v = gostergeler.get(key)
        if not v or v.get("guncel") is None:
            return "—"
        d   = v.get("degisim")
        d_s = f" ({'+' if d and d > 0 else ''}{d:.2f}{birim})" if d is not None else ""
        return f"{_fmt(v['guncel'], birim)}{d_s} {_trend(v.get('trend'))}"

    yorumHarita = (btcYorum or {}).get("yorumHarita", {})
    yorumlar = [
        f"<b>{ISIMLER[k]}:</b>\n{yorumHarita[k]}"
        for k in ["fedFaiz", "cpi", "nfp", "ppi", "ismImalat"]
        if yorumHarita.get(k)
    ]

    return (
        f"📋 <b>HAFTALIK MAKRO ÖZET — {zaman}</b>\n"
        f"<i>{hafta} haftası verileri</i>\n"
        f"━━━━━━━━━━━━━━━━━━━━━\n\n"
        f"<b>{sentez}</b>\n\n"
        f"📊 <b>Gösterge Tablosu:</b>\n"
        f"Fed Faiz    : {_g('fedFaiz', '%')}\n"
        f"TÜFE (CPI)  : {_g('cpi')}\n"
        f"NFP         : {_g('nfp', 'K')}\n"
        f"ÜFE (PPI)   : {_g('ppi', '%')}\n"
        f"İşsizlik    : {_g('iscabasvurusu', '%')}\n"
        f"GSYİH       : {_g('gsyih', '%')}\n"
        f"PCE         : {_g('pce', '%')}\n"
        f"ISM PMI     : {_g('ismImalat')}\n"
        f"Perakende   : {_g('perakende', ' Mr$')}\n\n"
        f"🔍 <b>BTC Yorumları:</b>\n\n"
        + "\n\n".join(yorumlar)
        + f"\n\n<i>Opsiyon Masası · Makro Ekonomi Modülü · {zaman}</i>"
    )


# ─── Değişim Tespiti ─────────────────────────────────────────
def _degisim_tespit(gostergeler: dict) -> list:
    """
    Eşiği aşan değişimleri bul.
    Her gösterge için ayrı 24 saat alarm engeli.
    """
    degisimler = []
    for key, esik in ESIKLER.items():
        v = gostergeler.get(key)
        if not v or v.get("guncel") is None:
            continue

        yeni = v["guncel"]
        with _bellek_lock:
            eski = _onceki.get(key)

        if eski is not None:
            fark = abs(yeni - eski)
            if fark >= esik:
                if not _alarm_gonderildi_mi(key):
                    degisimler.append({"key": key, "eski": eski, "yeni": yeni})
                else:
                    print(f"[MakroAlarm] {key} değişti ama 24s susturma aktif")

        # Her durumda güncel değeri sakla
        with _bellek_lock:
            _onceki[key] = yeni

    return degisimler


# ─── Cuma Haftalık Özet Kontrolü ────────────────────────────
def _haftalik_ozet_vakti() -> bool:
    """Cuma 20:00–20:30 TR arası mı?"""
    simdi = datetime.now(TR_TZ)
    return (
        simdi.weekday() == 4 and      # Cuma
        simdi.hour == 20 and          # 20:xx
        simdi.minute < 30             # :00–:29
    )


def _bu_hafta_str() -> str:
    """Örn: '2026-W21'"""
    simdi = datetime.now(TR_TZ)
    return f"{simdi.year}-W{simdi.isocalendar()[1]:02d}"


# ─── Ana Döngü ───────────────────────────────────────────────
def makro_alarm_loop():
    """
    Her 30 dakikada bir makro verileri kontrol eder.
    Eşiği aşan değişimleri ANINDA bildirir.
    Her Cuma 20:00 TR'de haftalık özet gönderir.

    bot.py'ye ekle:
        from makro_alarm import makro_alarm_loop
        threading.Thread(target=makro_alarm_loop, daemon=True).start()
    """
    global _son_haftalik
    print("[MakroAlarm] Başlatıldı — 30 dakika polling, anında değişim bildirimi")
    ARALIK = 30 * 60   # 30 dakika

    # ── İlk başlangıçta mevcut değerleri yükle (alarm üretme) ──
    print("[MakroAlarm] Başlangıç değerleri yükleniyor...")
    ilk = _veri_cek()
    if ilk:
        g = ilk.get("gostergeler", {})
        with _bellek_lock:
            for key in ESIKLER:
                v = g.get(key)
                if v and v.get("guncel") is not None:
                    _onceki[key] = v["guncel"]
        print(f"[MakroAlarm] {len(_onceki)} gösterge başlangıç değeri yüklendi — alarmlar aktif")
    else:
        print("[MakroAlarm] Başlangıç verisi alınamadı, ilk döngüde tekrar denenecek")

    while True:
        try:
            now_tr = datetime.now(TR_TZ)
            zaman  = now_tr.strftime("%d.%m.%Y %H:%M TR")
            print(f"[MakroAlarm] Kontrol — {zaman}")

            veri = _veri_cek()
            if not veri:
                print("[MakroAlarm] API verisi alınamadı, bekleniyor...")
                time.sleep(ARALIK)
                continue

            g  = veri.get("gostergeler", {})
            by = veri.get("btcYorum", {})

            # ── 1. Değişim tespiti — anında gönder ─────────────
            degisimler = _degisim_tespit(g)
            if degisimler:
                print(f"[MakroAlarm] {len(degisimler)} değişim: {[d['key'] for d in degisimler]}")
                mesaj = _degisim_mesaji(degisimler, g, by, zaman)
                # Her değişen göstergeyi kaydet (24s engeli için)
                for d in degisimler:
                    _alarm_kaydet(d["key"])
                _gonder(mesaj)
            else:
                print("[MakroAlarm] Eşiği aşan değişiklik yok")

            # ── 2. Cuma 20:00 TR — haftalık özet ───────────────
            bu_hafta = _bu_hafta_str()
            if _haftalik_ozet_vakti() and _son_haftalik != bu_hafta:
                print("[MakroAlarm] Haftalık özet gönderiliyor...")
                mesaj = _haftalik_ozet_mesaji(g, by, zaman, bu_hafta)
                _gonder(mesaj)
                _son_haftalik = bu_hafta
                print(f"[MakroAlarm] Haftalık özet gönderildi: {bu_hafta}")

        except Exception as e:
            print(f"[MakroAlarm] Genel hata: {e}")

        time.sleep(ARALIK)
