"""
Makro Alarm Modülü — FINAL
══════════════════════════════════════════════════════════════
MİMARİ:
  • bot.py ile AYNI process, AYNI PID
  • bot.py'deki _run_async inject edilir
  • Atomik lock — race condition imkansız
  • RAM + /tmp/ dedup

ZAMANLAMA:
  • Her 30 dakikada değişim kontrolü → anında bildir
  • Her Cuma 20:00-20:29 TR → haftalık özet
  • Aynı gösterge 24 saat içinde tekrar bildirilmez
"""

import os
import json
import time
import threading
import requests
import pytz
from datetime import datetime, timezone

# ─── Kanal ─────────────────────────────────────────────────────
MAKRO_CHAT_ID   = -1003896040852
MAKRO_THREAD_ID = 7
TR_TZ           = pytz.timezone("Europe/Istanbul")

# ─── Ayarlar ───────────────────────────────────────────────────
KONTROL_ARALIK = 30 * 60   # 30 dakika
SESSIZ_SURE    = 24 * 3600  # 24 saat — aynı gösterge tekrar bildirilmez
DURUM_DOSYA    = "/tmp/makro_alarm_durum.json"

ESIKLER = {
    "fedFaiz":       0.10,
    "cpi":           0.50,
    "nfp":           30.0,
    "ppi":           0.30,
    "iscabasvurusu": 0.10,
    "ismImalat":     1.00,
    "perakende":     3.00,
    "gsyih":         0.30,
    "pce":           0.30,
}

ISIMLER = {
    "fedFaiz":       "Fed Faiz / Hazine Bonosu",
    "cpi":           "TÜFE (CPI Endeksi)",
    "nfp":           "Tarım Dışı İstihdam (NFP)",
    "ppi":           "ÜFE (PPI Aylık %)",
    "iscabasvurusu": "İşsizlik Oranı",
    "gsyih":         "GSYİH Büyüme",
    "pce":           "PCE Tüketim",
    "ismImalat":     "ISM İmalat PMI",
    "perakende":     "Perakende Satışlar",
}

BIRIMLER = {
    "fedFaiz": "%", "cpi": "", "nfp": "K", "ppi": "%",
    "iscabasvurusu": "%", "gsyih": "%", "pce": "%",
    "ismImalat": "", "perakende": " Mr$",
}

# ─── Kilits ────────────────────────────────────────────────────
_ana_lock = threading.Lock()
_ram: dict = {}

# bot.py'den inject
_run_async_fn = None

# Haftalık özet takibi
_son_haftalik: str = ""

# Önceki değerler
_onceki: dict = {}
_onceki_lock  = threading.Lock()


def init(run_async_fn):
    """
    bot.py'den çağrılır:
        from makro_alarm import makro_alarm_loop, init as makro_init
        makro_init(_run_async)
    """
    global _run_async_fn
    _run_async_fn = run_async_fn
    print("[MakroAlarm] _run_async inject edildi ✓")


# ══════════════════════════════════════════════════════════════
# DOSYA
# ══════════════════════════════════════════════════════════════

def _dosya_oku() -> dict:
    try:
        with open(DURUM_DOSYA, "r") as f:
            return json.load(f)
    except Exception:
        return {}


def _dosya_yaz(data: dict):
    try:
        simdi = time.time()
        temiz = {k: v for k, v in data.items()
                 if simdi - v < SESSIZ_SURE * 1.5}
        with open(DURUM_DOSYA, "w") as f:
            json.dump(temiz, f)
    except Exception as e:
        print(f"[MakroAlarm] Dosya yazma: {e}")


# ══════════════════════════════════════════════════════════════
# ATOMİK KONTROL + KAYDET
# ══════════════════════════════════════════════════════════════

def _kontrol_ve_kaydet(anahtar: str) -> bool:
    simdi = time.time()

    son = _ram.get(anahtar, 0)
    if simdi - son < SESSIZ_SURE:
        kalan = int((son + SESSIZ_SURE - simdi) / 3600)
        print(f"[MakroAlarm] ⏸ RAM: {anahtar} ({kalan} saat kaldı)")
        return False

    data = _dosya_oku()
    son  = data.get(anahtar, 0)
    if simdi - son < SESSIZ_SURE:
        kalan = int((son + SESSIZ_SURE - simdi) / 3600)
        print(f"[MakroAlarm] ⏸ Dosya: {anahtar} ({kalan} saat kaldı)")
        _ram[anahtar] = son
        return False

    _ram[anahtar]   = simdi
    data[anahtar]   = simdi
    _dosya_yaz(data)
    print(f"[MakroAlarm] ✅ Yeni alarm: {anahtar}")
    return True


def _gonder_eger_yeni(anahtar: str, mesaj: str):
    with _ana_lock:
        gonder = _kontrol_ve_kaydet(anahtar)
    if gonder:
        _telegram_gonder(mesaj)


# ══════════════════════════════════════════════════════════════
# TELEGRAM
# ══════════════════════════════════════════════════════════════

async def _tg_async(mesaj: str):
    from telegram import Bot
    token = os.getenv("BOT_TOKEN")
    bot   = Bot(token=token)
    parcalar = [mesaj[i:i+4096] for i in range(0, len(mesaj), 4096)]
    for parca in parcalar:
        await bot.send_message(
            chat_id=MAKRO_CHAT_ID,
            text=parca,
            parse_mode="HTML",
            message_thread_id=MAKRO_THREAD_ID,
            disable_web_page_preview=True,
        )


def _telegram_gonder(mesaj: str):
    try:
        if _run_async_fn:
            _run_async_fn(_tg_async(mesaj))
        else:
            import asyncio
            loop = asyncio.new_event_loop()
            loop.run_until_complete(_tg_async(mesaj))
            loop.close()
        print("[MakroAlarm] ✓ Gönderildi")
    except Exception as e:
        print(f"[MakroAlarm] Telegram hatası: {e}")


# ══════════════════════════════════════════════════════════════
# VERİ
# ══════════════════════════════════════════════════════════════

MAKRO_API_URL = os.getenv(
    "MAKRO_API_URL",
    "https://options-desk.vercel.app/api/macro?module=all"
)


def _veri_cek() -> dict | None:
    try:
        r = requests.get(MAKRO_API_URL, timeout=30)
        r.raise_for_status()
        return r.json()
    except Exception as e:
        print(f"[MakroAlarm] API hatası: {e}")
        return None


# ══════════════════════════════════════════════════════════════
# DEĞİŞİM TESPİTİ
# ══════════════════════════════════════════════════════════════

def _degisim_tespit(gostergeler: dict) -> list:
    degisimler = []
    with _onceki_lock:
        for key, esik in ESIKLER.items():
            v = gostergeler.get(key)
            if not v or v.get("guncel") is None:
                continue
            yeni  = v["guncel"]
            eski  = _onceki.get(key)
            if eski is not None and abs(yeni - eski) >= esik:
                degisimler.append({"key": key, "eski": eski, "yeni": yeni})
            _onceki[key] = yeni
    return degisimler


# ══════════════════════════════════════════════════════════════
# MESAJ FORMATLARI
# ══════════════════════════════════════════════════════════════

def _fmt(d, b="") -> str:
    if d is None:
        return "—"
    return f"{d:.2f}{b}" if abs(d) < 1000 else f"{d:,.0f}{b}"


def _trend(t: str) -> str:
    return {"yukari": "▲", "asagi": "▼", "sabit": "→"}.get(t or "", "—")


def _degisim_mesaji(degisimler: list, gostergeler: dict,
                    btcYorum: dict, zaman: str) -> str:
    sentez = (btcYorum or {}).get("sentez", "")
    genel  = ("📗 OLUMLU" if "OLUMLU" in sentez else
              "📕 OLUMSUZ" if "OLUMSUZ" in sentez else "📙 NÖTR")

    satirlar = []
    for d in degisimler:
        key    = d["key"]
        birim  = BIRIMLER.get(key, "")
        fark   = d["yeni"] - d["eski"]
        isaret = "✅" if (fark < 0) == (key in {"cpi","nfp","ppi","perakende"}) else "⚠️"
        satirlar.append(
            f"• <b>{ISIMLER.get(key,key)}</b>: "
            f"{_fmt(d['yeni'],birim)} "
            f"(önceki: {_fmt(d['eski'],birim)}) "
            f"{isaret} {'+' if fark>0 else ''}{fark:.2f}{birim}"
        )

    yh = (btcYorum or {}).get("yorumHarita", {})
    yorumlar = [
        f"• {yh[d['key']]}" for d in degisimler[:3] if yh.get(d["key"])
    ]

    m = (f"🔔 <b>MAKRO VERİ DEĞİŞİKLİĞİ</b>\n"
         f"━━━━━━━━━━━━━━━━━━━━━\n"
         f"<b>BTC Görünümü: {genel}</b>\n\n"
         f"📊 <b>Değişen ({len(degisimler)}):</b>\n"
         + "\n".join(satirlar))
    if yorumlar:
        m += "\n\n💬 <b>BTC Etkisi:</b>\n" + "\n\n".join(yorumlar)
    m += f"\n\n<i>Opsiyon Masası · {zaman}</i>"
    return m


def _haftalik_ozet_mesaji(gostergeler: dict, btcYorum: dict,
                           zaman: str, hafta: str) -> str:
    sentez = (btcYorum or {}).get("sentez", "")

    def _g(key):
        v = gostergeler.get(key)
        if not v or v.get("guncel") is None:
            return "—"
        b = BIRIMLER.get(key, "")
        d = v.get("degisim")
        ds = f" ({'+' if d and d>0 else ''}{d:.2f}{b})" if d is not None else ""
        return f"{_fmt(v['guncel'],b)}{ds} {_trend(v.get('trend'))}"

    yh = (btcYorum or {}).get("yorumHarita", {})
    yorumlar = [
        f"<b>{ISIMLER[k]}:</b>\n{yh[k]}"
        for k in ["fedFaiz","cpi","nfp","ppi","ismImalat"]
        if yh.get(k)
    ]

    return (
        f"📋 <b>HAFTALIK MAKRO ÖZET — {zaman}</b>\n"
        f"<i>{hafta}</i>\n"
        f"━━━━━━━━━━━━━━━━━━━━━\n\n"
        f"<b>{sentez}</b>\n\n"
        f"📊 <b>Göstergeler:</b>\n"
        f"Fed Faiz   : {_g('fedFaiz')}\n"
        f"TÜFE       : {_g('cpi')}\n"
        f"NFP        : {_g('nfp')}\n"
        f"ÜFE        : {_g('ppi')}\n"
        f"İşsizlik   : {_g('iscabasvurusu')}\n"
        f"GSYİH      : {_g('gsyih')}\n"
        f"PCE        : {_g('pce')}\n"
        f"ISM PMI    : {_g('ismImalat')}\n"
        f"Perakende  : {_g('perakende')}\n\n"
        f"🔍 <b>BTC Yorumları:</b>\n\n"
        + "\n\n".join(yorumlar)
        + f"\n\n<i>Opsiyon Masası · {zaman}</i>"
    )


# ══════════════════════════════════════════════════════════════
# CUMA HAFTALIK ÖZET
# ══════════════════════════════════════════════════════════════

def _haftalik_vakti() -> bool:
    simdi = datetime.now(TR_TZ)
    return simdi.weekday() == 4 and simdi.hour == 20 and simdi.minute < 30


def _bu_hafta() -> str:
    simdi = datetime.now(TR_TZ)
    return f"{simdi.year}-W{simdi.isocalendar()[1]:02d}"


# ══════════════════════════════════════════════════════════════
# BAŞLANGIÇ
# ══════════════════════════════════════════════════════════════

def _baslangic_yukle():
    data  = _dosya_oku()
    simdi = time.time()
    aktif = 0
    for k, v in data.items():
        if simdi - v < SESSIZ_SURE:
            _ram[k] = v
            aktif  += 1
    print(f"[MakroAlarm] {aktif} susturma yüklendi" if aktif
          else "[MakroAlarm] Hafıza temiz")


# ══════════════════════════════════════════════════════════════
# ANA DÖNGÜ
# ══════════════════════════════════════════════════════════════

def makro_alarm_loop():
    global _son_haftalik

    print("[MakroAlarm] ═══ Başlatıldı ═══")
    print(f"[MakroAlarm] 30dk polling | 24s susturma | Cuma 20:00 özet")
    _baslangic_yukle()

    # İlk çalıştırmada önceki değerleri yükle (alarm üretme)
    print("[MakroAlarm] Başlangıç değerleri yükleniyor...")
    ilk = _veri_cek()
    if ilk:
        g = ilk.get("gostergeler", {})
        with _onceki_lock:
            for key in ESIKLER:
                v = g.get(key)
                if v and v.get("guncel") is not None:
                    _onceki[key] = v["guncel"]
        print(f"[MakroAlarm] {len(_onceki)} gösterge başlangıç değeri yüklendi")

    while True:
        try:
            zaman  = datetime.now(TR_TZ).strftime("%d.%m.%Y %H:%M TR")
            print(f"[MakroAlarm] Kontrol — {zaman}")

            veri = _veri_cek()
            if not veri:
                print("[MakroAlarm] API yanıt vermedi")
                time.sleep(KONTROL_ARALIK)
                continue

            g  = veri.get("gostergeler", {})
            by = veri.get("btcYorum", {})

            # ── Değişim tespiti → anında bildir ────────────────
            degisimler = _degisim_tespit(g)
            if degisimler:
                print(f"[MakroAlarm] {len(degisimler)} değişim: "
                      f"{[d['key'] for d in degisimler]}")
                mesaj = _degisim_mesaji(degisimler, g, by, zaman)
                # Her değişen gösterge için ayrı anahtar
                anahtar = "degisim_" + "_".join(d["key"] for d in degisimler)
                _gonder_eger_yeni(anahtar, mesaj)
            else:
                print("[MakroAlarm] Eşiği aşan değişiklik yok")

            # ── Cuma 20:00 TR haftalık özet ────────────────────
            bu_hafta = _bu_hafta()
            if _haftalik_vakti() and _son_haftalik != bu_hafta:
                print("[MakroAlarm] Haftalık özet gönderiliyor...")
                mesaj = _haftalik_ozet_mesaji(g, by, zaman, bu_hafta)
                _telegram_gonder(mesaj)   # Özet her hafta 1 kez — ayrı kontrol
                _son_haftalik = bu_hafta
                print(f"[MakroAlarm] Haftalık özet gönderildi: {bu_hafta}")

        except Exception as e:
            print(f"[MakroAlarm] Hata: {e}")

        time.sleep(KONTROL_ARALIK)
